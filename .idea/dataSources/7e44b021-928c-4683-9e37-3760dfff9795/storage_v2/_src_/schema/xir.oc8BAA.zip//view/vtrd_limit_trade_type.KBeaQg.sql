create view vtrd_limit_trade_type as
select `T`.`TRD_TYPE`                     AS `TRD_TYPE`,
       `T`.`ISPERIOD_INST`                AS `ISPERIOD_INST`,
       coalesce(`TDML`.`DICT_VALUE`, '0') AS `LIMIT_TYPE`
from (`xir`.`ttrd_trade_type` `T`
         left join `xir`.`ttrd_dict_mult_lang` `TDML` on (((`TDML`.`DICT_KEY` = `T`.`TRD_TYPE`) and
                                                           (`TDML`.`DICT_SUB_TYPE` = 'CalcLimitInTheorySettle'))));

