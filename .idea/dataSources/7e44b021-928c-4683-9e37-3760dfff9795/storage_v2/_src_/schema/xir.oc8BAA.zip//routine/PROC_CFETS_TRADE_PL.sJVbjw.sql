create
    definer = root@`%` procedure PROC_CFETS_TRADE_PL(IN PI_ORDDATE varchar(30), IN PI_CLIENT_ID varchar(30),
                                                     IN PI_CLORDID_CLIENT_ID varchar(30), IN PI_ORIGCLORDID varchar(30),
                                                     IN PI_SERIAL_NO varchar(30), IN PI_ORDERID varchar(30),
                                                     IN PI_TRANSACTTIME varchar(30), IN PI_QUOTETRANSTYPE varchar(30),
                                                     IN PI_MARKETINDICATOR varchar(30), IN PI_SECURITYTYPE varchar(30),
                                                     IN PI_ORDTYPE decimal(18), IN PI_EXPIRETIME varchar(30),
                                                     IN PI_SECURITYID varchar(30), IN PI_SIDE varchar(30),
                                                     IN PI_MATURITYYIELD varchar(30), IN PI_STRIKEYIELD varchar(30),
                                                     IN PI_PRICE varchar(30), IN PI_ORDERQTY varchar(30),
                                                     IN PI_DELIVERYTYPE varchar(30), IN PI_CLEARINGMETHOD varchar(30),
                                                     IN PI_SETTLTYPE varchar(30), IN PI_SPLITINDICATOR varchar(30),
                                                     IN PI_MINTICKSIZE varchar(30), IN PI_PARTYID varchar(30),
                                                     IN PI_TRADERID varchar(30),
                                                     IN PI_CUSTODIAN_INSTITUTION_NAME varchar(50),
                                                     IN PI_CUSTODIAN_ACCT_NUMBER varchar(30),
                                                     IN PI_CASH_BANK_NAME varchar(50),
                                                     IN PI_CASH_ACCT_NUMBER varchar(30),
                                                     IN PI_VALIDUNTILTIME varchar(30), IN PI_PARENTORDERID varchar(30),
                                                     IN PI_CONTINGENCYINDICATOR varchar(30), IN PI_SYMBOL varchar(30),
                                                     IN PI_DIRTYPRICE varchar(30), IN PI_ACCRUEDINTERESTAMT varchar(30),
                                                     IN PI_LEAVESQTY varchar(30), IN PI_TRADECASHAMT varchar(30),
                                                     IN PI_QUOTETYPE varchar(30),
                                                     IN PI_ACCRUEDINTERESTTOTALAMT varchar(30),
                                                     IN PI_SETTLCURRAMT varchar(30), IN PI_SETTLDATE varchar(30),
                                                     IN PI_PRINCIPAL varchar(30), IN PI_TOTALPRINCIPAL varchar(30),
                                                     IN PI_PARTYNAME varchar(50), IN PI_TRADERNAME varchar(50),
                                                     IN PI_UPDATETIME varchar(30), IN PI_LEAVESTOTALQTY varchar(30),
                                                     IN PI_ACTION varchar(30), IN PI_USERNAME varchar(30),
                                                     OUT PO_ERRORCODE varchar(30), OUT PO_ERRORMSG varchar(1000),
                                                     OUT PO_QID decimal(18), OUT PO_CLORDID varchar(30))
label_a:BEGIN
  DECLARE V_COUNT DECIMAL(18,0);
  DECLARE V_QID   DECIMAL(18,0);
  SET V_COUNT      = 0;
  SET V_QID        = 0;
  SET PO_QID       = 0;
  SET PO_ERRORCODE = '0';
  SET PO_ERRORMSG  = '';
  SET PO_CLORDID   = '';

  SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_B_TRADE_HOLIDAY
   WHERE MARKETINDICATOR = PI_MARKETINDICATOR AND HOLIDAY = PI_ORDDATE;
  IF V_COUNT > 0 THEN
    SET PO_ERRORCODE = '-30002';
    SET PO_ERRORMSG  = '禁止报价-节假日';
    LEAVE label_a;
  END IF;

  IF PI_QUOTETRANSTYPE = 'N' THEN
    SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_TRADE_PL
     WHERE CLIENT_ID = PI_CLIENT_ID AND CLORDID_CLIENT_ID = PI_CLORDID_CLIENT_ID
       AND (STATUS = 0 OR STATUS = 1 OR STATUS = 5 OR STATUS = 10 OR STATUS = 11);
    IF V_COUNT > 0 THEN
      SET PO_ERRORCODE = '-30005';
      SET PO_ERRORMSG  = '禁止报价-重复报价';
      LEAVE label_a;
    END IF;
  ELSEIF PI_QUOTETRANSTYPE = 'C' THEN
    SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_TRADE_PL WHERE CLORDID = PI_ORIGCLORDID
       AND (STATUS = 5 OR STATUS = 10) AND (ACT_STATUS <> 0 AND ACT_STATUS <> 1);
    IF V_COUNT <> 1 THEN
      SET PO_ERRORCODE = '-30007';
      SET PO_ERRORMSG  = '没有可撤销的原报价信息';
      LEAVE label_a;
    END IF;
  ELSE
    SET PO_ERRORCODE = '-20001';
    SET PO_ERRORMSG  = '请求消息QUOTETRANSTYPE参数无效';
    LEAVE label_a;
  END IF;
  SELECT NEXTVAL('S_AUTOINC_CFETS_TRADE_QID') INTO PO_QID FROM DUAL;

  SET PO_CLORDID = PO_QID;
  IF CHAR_LENGTH(PO_CLORDID) > 8 THEN
    SET PO_CLORDID = LEFT(PO_CLORDID, 8);
  ELSEIF CHAR_LENGTH(PO_CLORDID) < 8 THEN
    WHILE CHAR_LENGTH(PO_CLORDID) < 8 DO
		SET PO_CLORDID = CONCAT(PO_CLORDID,'0');
    END WHILE;
  END IF;
  SET PO_CLORDID = CONCAT('OD',PI_USERNAME,PO_CLORDID);

  INSERT INTO TTRD_CFETS_TRADE_PL_SEND
    (QID,
     CLIENT_ID,
     CLORDID_CLIENT_ID,
     CLORDID,
     ORIGCLORDID,
     SERIAL_NO,
     ORDERID,
     QUOTETRANSTYPE,
     MARKETINDICATOR,
     SECURITYTYPE,
     ORDTYPE,
     EXPIRETIME,
     SECURITYID,
     SIDE,
     MATURITYYIELD,
     STRIKEYIELD,
     PRICE,
     ORDERQTY,
     DELIVERYTYPE,
     CLEARINGMETHOD,
     SETTLTYPE,
     SPLITINDICATOR,
     MINTICKSIZE,
     PARTYID,
     TRADERID,
     CUSTODIAN_INSTITUTION_NAME,
     CUSTODIAN_ACCT_NUMBER,
     CASH_BANK_NAME,
     CASH_ACCT_NUMBER,
     VALIDUNTILTIME,
     PARENTORDERID,
     CONTINGENCYINDICATOR,
     SYMBOL,
     DIRTYPRICE,
     ACCRUEDINTERESTAMT,
     LEAVESQTY,
     TRADECASHAMT,
     QUOTETYPE,
     ACCRUEDINTERESTTOTALAMT,
     SETTLCURRAMT,
     SETTLDATE,
     PRINCIPAL,
     TOTALPRINCIPAL,
     PARTYNAME,
     TRADERNAME,
     STATUS,
     ERRORCODE,
     ERRORMSG,
     UPDATETIME,
     LEAVESTOTALQTY,
     ACTION)
  VALUES
    (PO_QID,
     PI_CLIENT_ID,
     PI_CLORDID_CLIENT_ID,
     PO_CLORDID,
     PI_ORIGCLORDID,
     PI_SERIAL_NO,
     PI_ORDERID,
     PI_QUOTETRANSTYPE,
     PI_MARKETINDICATOR,
     PI_SECURITYTYPE,
     PI_ORDTYPE,
     PI_EXPIRETIME,
     PI_SECURITYID,
     PI_SIDE,
     PI_MATURITYYIELD,
     PI_STRIKEYIELD,
     PI_PRICE,
     PI_ORDERQTY,
     PI_DELIVERYTYPE,
     PI_CLEARINGMETHOD,
     PI_SETTLTYPE,
     PI_SPLITINDICATOR,
     PI_MINTICKSIZE,
     PI_PARTYID,
     PI_TRADERID,
     PI_CUSTODIAN_INSTITUTION_NAME,
     PI_CUSTODIAN_ACCT_NUMBER,
     PI_CASH_BANK_NAME,
     PI_CASH_ACCT_NUMBER,
     PI_VALIDUNTILTIME,
     PI_PARENTORDERID,
     PI_CONTINGENCYINDICATOR,
     PI_SYMBOL,
     PI_DIRTYPRICE,
     PI_ACCRUEDINTERESTAMT,
     PI_LEAVESQTY,
     PI_TRADECASHAMT,
     PI_QUOTETYPE,
     PI_ACCRUEDINTERESTTOTALAMT,
     PI_SETTLCURRAMT,
     PI_SETTLDATE,
     PI_PRINCIPAL,
     PI_TOTALPRINCIPAL,
     PI_PARTYNAME,
     PI_TRADERNAME,
     0,
     PO_ERRORCODE,
     PO_ERRORMSG,
     PI_UPDATETIME,
     PI_LEAVESTOTALQTY,
     PI_ACTION);

  IF PI_QUOTETRANSTYPE = 'N' THEN
    SELECT NEXTVAL('S_AUTOINC_CFETS_TRADE_QID') INTO V_QID FROM DUAL;
    INSERT INTO TTRD_CFETS_TRADE_PL
      (QID,
       CLIENT_ID,
       CLORDID_CLIENT_ID,
       CLORDID,
       ORDERID,
       TRANSACTTIME,
       ORDERQTY,
       ORDTYPE,
       PRICE,
       SECURITYID,
       SIDE,
       EXPIRETIME,
       SETTLTYPE,
       MINTICKSIZE,
       MARKETINDICATOR,
       SECURITYTYPE,
       CLEARINGMETHOD,
       SPLITINDICATOR,
       MATURITYYIELD,
       STRIKEYIELD,
       PARTYID,
       TRADERID,
       CASH_BANK_NAME,
       CASH_ACCT_NUMBER,
       CUSTODIAN_ACCT_NUMBER,
       CUSTODIAN_INSTITUTION_NAME,
       STATUS,
       ERRORCODE,
       ERRORMSG,
       UPDATETIME,
       QUOTETRANSTYPE,
       SYMBOL,
       ACCRUEDINTERESTAMT,
       ACCRUEDINTERESTTOTALAMT,
       DIRTYPRICE,
       SETTLCURRAMT,
       TRADECASHAMT,
       SETTLDATE,
       QUOTETYPE,
       VALIDUNTILTIME,
       PARENTORDERID,
       CONTINGENCYINDICATOR,
       LEAVESQTY,
       PRINCIPAL,
       TOTALPRINCIPAL,
       PARTYNAME,
       TRADERNAME,
       DELIVERYTYPE,
       LEAVESTOTALQTY,
       ACT_QID,
       ACT_STATUS,
       ACT_ERRORCODE,
       ACT_ERRORMSG,
       SEND_RECV_FLAG,
       ACT_TYPE,
       ACTION)
    VALUES
      (V_QID,
       PI_CLIENT_ID,
       PI_CLORDID_CLIENT_ID,
       PO_CLORDID,
       PI_ORDERID,
       PI_TRANSACTTIME,
       PI_ORDERQTY,
       PI_ORDTYPE,
       PI_PRICE,
       PI_SECURITYID,
       PI_SIDE,
       PI_EXPIRETIME,
       PI_SETTLTYPE,
       PI_MINTICKSIZE,
       PI_MARKETINDICATOR,
       PI_SECURITYTYPE,
       PI_CLEARINGMETHOD,
       PI_SPLITINDICATOR,
       PI_MATURITYYIELD,
       PI_STRIKEYIELD,
       PI_PARTYID,
       PI_TRADERID,
       PI_CASH_BANK_NAME,
       PI_CASH_ACCT_NUMBER,
       PI_CUSTODIAN_ACCT_NUMBER,
       PI_CUSTODIAN_INSTITUTION_NAME,
       0,
       PO_ERRORCODE,
       PO_ERRORMSG,
       PI_UPDATETIME,
       PI_QUOTETRANSTYPE,
       PI_SYMBOL,
       PI_ACCRUEDINTERESTAMT,
       PI_ACCRUEDINTERESTTOTALAMT,
       PI_DIRTYPRICE,
       PI_SETTLCURRAMT,
       PI_TRADECASHAMT,
       PI_SETTLDATE,
       PI_QUOTETYPE,
       PI_VALIDUNTILTIME,
       PI_PARENTORDERID,
       PI_CONTINGENCYINDICATOR,
       PI_LEAVESQTY,
       PI_PRINCIPAL,
       PI_TOTALPRINCIPAL,
       PI_PARTYNAME,
       PI_TRADERNAME,
       PI_DELIVERYTYPE,
       PI_LEAVESTOTALQTY,
       PO_QID,
       0,
       PO_ERRORCODE,
       PO_ERRORMSG,
       'SEND',
       PI_QUOTETRANSTYPE,
       PI_ACTION);
  ELSEIF PI_QUOTETRANSTYPE = 'C' THEN
    UPDATE TTRD_CFETS_TRADE_PL
       SET ACT_QID     = PO_QID,
       ACT_STATUS    = 0,
           ACT_ERRORCODE = PO_ERRORCODE,
           ACT_ERRORMSG  = PO_ERRORMSG,
           ACT_TYPE      = PI_QUOTETRANSTYPE,
           UPDATETIME    = PI_UPDATETIME
     WHERE ORDERID = PI_ORDERID;
  END IF;
END;

