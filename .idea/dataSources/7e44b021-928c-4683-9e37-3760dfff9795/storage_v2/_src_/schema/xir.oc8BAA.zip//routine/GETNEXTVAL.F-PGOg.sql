create
    definer = root@localhost function GETNEXTVAL(p_con varchar(400)) returns varchar(400)
BEGIN
DECLARE v_con VARCHAR(400);
DECLARE con varchar(40);
set v_con = p_con;
UPDATE SEQUENCE SET CURRENT_VAL = CURRENT_VAL + 1 WHERE SEQ_NAME = v_con;
SELECT CURRENT_VAL into con FROM SEQUENCE S WHERE S.SEQ_NAME = v_con;
return con;
end;

