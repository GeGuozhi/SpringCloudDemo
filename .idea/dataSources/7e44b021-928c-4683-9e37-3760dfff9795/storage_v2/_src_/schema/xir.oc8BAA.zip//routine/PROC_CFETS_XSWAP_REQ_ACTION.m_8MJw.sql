create
    definer = root@`%` procedure PROC_CFETS_XSWAP_REQ_ACTION(IN PI_USERNAME varchar(30), IN PI_CLIENTID varchar(30),
                                                             IN PI_CLIENTREQID varchar(30), IN PI_ACTDATE varchar(30),
                                                             IN PI_ACTTIME varchar(30), IN PI_APPLTOKEN varchar(30),
                                                             IN PI_ORDERCANCELTYPE varchar(30),
                                                             IN PI_ORIGOPERATESEQNUM varchar(30),
                                                             IN PI_ORDERID varchar(30),
                                                             IN PI_MARKETINDICATOR varchar(30),
                                                             IN PI_SECURITYTYPE varchar(30),
                                                             IN PI_CLEARINGMETHOD varchar(30), IN PI_PARTY varchar(30),
                                                             IN PI_TRADER varchar(30), IN PI_STATUS decimal(18),
                                                             IN PI_FB_OPERATESEQNUM varchar(30),
                                                             IN PI_UPDATETIME varchar(30), IN PI_SERIALNO varchar(30),
                                                             IN PI_QUOTESOURCE varchar(30),
                                                             IN PI_CREATETIME varchar(30), OUT PO_SYSREQID varchar(30),
                                                             OUT PO_ORDERREQUESTID varchar(30),
                                                             OUT PO_ERRCODE varchar(30), OUT PO_ERRINFO varchar(1000))
label_a:BEGIN
  DECLARE V_COUNT DECIMAL(18,0);
  DECLARE V_DATE VARCHAR(30);
  SET V_DATE = '';
  SET PO_ERRCODE = '0';
  SET PO_ERRINFO  = '禁止重复报价';

  SELECT curdate() INTO V_DATE FROM DUAL;
  SET V_DATE = CONCAT(V_DATE, ' 00:00:00.000');
  
  SELECT COUNT(1)
    INTO V_COUNT
    FROM TTRD_XSWAP_ACTION
   WHERE CLIENTID = PI_CLIENTID
     AND CLIENTREQID = PI_CLIENTREQID
     AND ACTDATE = PI_ACTDATE
     AND (STATUS = 0 OR STATUS = 1 OR STATUS = 2 OR STATUS = 3 OR STATUS = 5 OR STATUS = 6)
	 AND UPDATETIME > V_DATE;
  IF V_COUNT > 0 THEN
    SET PO_ERRCODE := '-30006';
    SET PO_ERRINFO := '';
    LEAVE label_a;
  END IF;

  SELECT NEXTVAL('S_AUTOINC_XSWAP_SYSREQID') INTO PO_SYSREQID FROM DUAL;
  SET PO_ORDERREQUESTID = PO_SYSREQID;
  IF CHAR_LENGTH(PO_ORDERREQUESTID) > 8 THEN
    SET PO_ORDERREQUESTID = LEFT(PO_ORDERREQUESTID, 8);
  ELSEIF CHAR_LENGTH(PO_ORDERREQUESTID) < 8 THEN
    WHILE CHAR_LENGTH(PO_ORDERREQUESTID) < 8 DO
		SET PO_ORDERREQUESTID = CONCAT('0',PO_ORDERREQUESTID);
    END WHILE;
  END IF;
  SET PO_ORDERREQUESTID = CONCAT('ORDE',REPLACE(PI_ACTDATE, '-', ''),PI_USERNAME,PO_ORDERREQUESTID);
  
  IF CHAR_LENGTH(PI_CLEARINGMETHOD) <= 0 THEN
	SET PI_CLEARINGMETHOD = null;
  END IF;

  INSERT INTO TTRD_XSWAP_ACTION
    (SYSREQID,
     CLIENTID,
     CLIENTREQID,
     ACTDATE,
     ACTTIME,
     ORDERREQUESTID,
     APPLTOKEN,
     ORDERCANCELTYPE,
     ORIGOPERATESEQNUM,
     ORDERID,
     MARKETINDICATOR,
     SECURITYTYPE,
     CLEARINGMETHOD,
     PARTY,
     TRADER,
     STATUS,
     ERRCODE,
     ERRINFO,
     FB_OPERATESEQNUM,
     UPDATETIME,
     SERIALNO,
	 QUOTESOURCE,
	 CREATETIME)
  VALUES
    (PO_SYSREQID,
     PI_CLIENTID,
     PI_CLIENTREQID,
     PI_ACTDATE,
     PI_ACTTIME,
     PO_ORDERREQUESTID,
     PI_APPLTOKEN,
     PI_ORDERCANCELTYPE,
     PI_ORIGOPERATESEQNUM,
     PI_ORDERID,
     PI_MARKETINDICATOR,
     PI_SECURITYTYPE,
     PI_CLEARINGMETHOD,
     PI_PARTY,
     PI_TRADER,
     PI_STATUS,
     PO_ERRCODE,
     PO_ERRINFO,
     PI_FB_OPERATESEQNUM,
     PI_UPDATETIME,
     PI_SERIALNO,
	 PI_QUOTESOURCE,
	 PI_CREATETIME);
	 
END;

