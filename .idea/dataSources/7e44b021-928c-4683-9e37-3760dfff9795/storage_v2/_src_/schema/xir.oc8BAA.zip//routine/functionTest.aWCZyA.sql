create
    definer = root@localhost function functionTest(p_con varchar(400)) returns varchar(400)
BEGIN
DECLARE v_con VARCHAR(400);
set v_con = p_con;
SELECT p_con into v_con;
return v_con;
end;

