create
    definer = root@`%` procedure PROC_CFETS_TRADE_CD(IN PI_ORDDATE varchar(30), IN PI_CLIENT_ID varchar(30),
                                                     IN PI_CLORDID_CLIENT_ID varchar(30), IN PI_ORIGCLORDID varchar(30),
                                                     IN PI_SERIAL_NO varchar(30), IN PI_QUOTETRANSTYPE varchar(30),
                                                     IN PI_ANONYMOUSINDICATOR varchar(30),
                                                     IN PI_SECURITYTYPE varchar(30), IN PI_MARKETINDICATOR varchar(30),
                                                     IN PI_QUOTETYPE varchar(30), IN PI_VALIDUNTILTIME varchar(30),
                                                     IN PI_SECURITYID varchar(30), IN PI_SIDE varchar(30),
                                                     IN PI_MAXFLOOR varchar(30), IN PI_MINTICKSIZE varchar(30),
                                                     IN PI_PRICE varchar(30), IN PI_ORDERQTY varchar(30),
                                                     IN PI_SETTLTYPE varchar(30), IN PI_CLEARINGMETHOD varchar(30),
                                                     IN PI_DELIVERYTYPE varchar(30), IN PI_MATURITYYIELD varchar(30),
                                                     IN PI_STRIKEYIELD varchar(30), IN PI_PARTYID varchar(30),
                                                     IN PI_TRADERID varchar(30), IN PI_CASH_ACCT_NUMBER varchar(30),
                                                     IN PI_CUSTODIAN_ACCT_NUMBER varchar(30),
                                                     IN PI_CUSTODIAN_INSTITUTION_NAME varchar(50),
                                                     IN PI_SETTLCURRENCY varchar(30), IN PI_SETTLCURRFXRATE varchar(30),
                                                     IN PI_REFERENCE varchar(30), IN PI_TRADERNAME varchar(50),
                                                     IN PI_CONTINGENCYINDICATOR varchar(30),
                                                     IN PI_LEAVESQTY varchar(30), IN PI_PRINCIPAL varchar(30),
                                                     IN PI_TOTALPRINCIPAL varchar(30), IN PI_PARTYNAME varchar(50),
                                                     IN PI_CASH_BANK_NAME varchar(50), IN PI_UPDATETIME varchar(30),
                                                     IN PI_ACTION varchar(30), IN PI_USERNAME varchar(30),
                                                     IN PI_QUOTEID varchar(30), OUT PO_ERRORCODE varchar(1000),
                                                     OUT PO_ERRORMSG varchar(30), OUT PO_QID decimal(18),
                                                     OUT PO_CLORDID varchar(30))
label_a:BEGIN
  DECLARE V_COUNT DECIMAL(18,0);
  DECLARE V_QID   DECIMAL(18,0);
  SET V_COUNT      = 0;
  SET V_QID        = 0;
  SET PO_QID       = 0;
  SET PO_ERRORCODE = '0';
  SET PO_ERRORMSG  = '';
  SET PO_CLORDID   = '';

  SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_B_TRADE_HOLIDAY
   WHERE MARKETINDICATOR = PI_MARKETINDICATOR AND HOLIDAY = PI_ORDDATE;
  IF V_COUNT > 0 THEN
    SET PO_ERRORCODE = '-30002';
    SET PO_ERRORMSG  = '禁止报价-节假日';
    LEAVE label_a;
  END IF;
  IF PI_QUOTETRANSTYPE = 'N' THEN
    SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_TRADE_CD
     WHERE CLIENT_ID = PI_CLIENT_ID AND CLORDID_CLIENT_ID = PI_CLORDID_CLIENT_ID
       AND (STATUS = 0 OR STATUS = 1 OR STATUS = 5 OR STATUS = 10 OR STATUS = 11);
    IF V_COUNT > 0 THEN
      SET PO_ERRORCODE = '-30005';
      SET PO_ERRORMSG  = '禁止报价-重复报价';
      LEAVE label_a;
    END IF;
  ELSEIF PI_QUOTETRANSTYPE = 'C' THEN
    SELECT COUNT(1) INTO V_COUNT FROM TTRD_CFETS_TRADE_CD
     WHERE CLORDID = PI_ORIGCLORDID AND (STATUS = 5 OR STATUS = 10)
       AND (ACT_STATUS <> 0 AND ACT_STATUS <> 1);
    IF V_COUNT <> 1 THEN
      SET PO_ERRORCODE = '-30007';
      SET PO_ERRORMSG  = '没有可撤销的原报价信息';
      LEAVE label_a;
    END IF;
  ELSE
    SET PO_ERRORCODE = '-20001';
    SET PO_ERRORMSG  = '请求消息QUOTETRANSTYPE参数无效';
    LEAVE label_a;
  END IF;
  SELECT NEXTVAL('S_AUTOINC_CFETS_TRADE_QID') INTO PO_QID FROM DUAL;

  SET PO_CLORDID = PO_QID;
  IF CHAR_LENGTH(PO_CLORDID) > 8 THEN
    SET PO_CLORDID = LEFT(PO_CLORDID, 8);
  ELSEIF CHAR_LENGTH(PO_CLORDID) < 8 THEN
    WHILE CHAR_LENGTH(PO_CLORDID) < 8 DO
		SET PO_CLORDID = CONCAT(PO_CLORDID,'0');
    END WHILE;
  END IF;
  SET PO_CLORDID = CONCAT('OD',PI_USERNAME,PO_CLORDID);

  INSERT INTO TTRD_CFETS_TRADE_CD_SEND
    (QID,
     CLIENT_ID,
     CLORDID_CLIENT_ID,
     CLORDID,
     ORIGCLORDID,
     SERIAL_NO,
     QUOTETRANSTYPE,
     ANONYMOUSINDICATOR,
     SECURITYTYPE,
     MARKETINDICATOR,
     QUOTETYPE,
     VALIDUNTILTIME,
     SECURITYID,
     SIDE,
     MAXFLOOR,
     MINTICKSIZE,
     PRICE,
     ORDERQTY,
     SETTLTYPE,
     CLEARINGMETHOD,
     DELIVERYTYPE,
     MATURITYYIELD,
     STRIKEYIELD,
     PARTYID,
     TRADERID,
     CASH_ACCT_NUMBER,
     CUSTODIAN_ACCT_NUMBER,
     CUSTODIAN_INSTITUTION_NAME,
     SETTLCURRENCY,
     SETTLCURRFXRATE,
     REFERENCE,
     TRADERNAME,
     CONTINGENCYINDICATOR,
     LEAVESQTY,
     PRINCIPAL,
     TOTALPRINCIPAL,
     PARTYNAME,
     CASH_BANK_NAME,
     STATUS,
     ERRORCODE,
     ERRORMSG,
     UPDATETIME,
     ACTION,
	 QUOTEID)
  VALUES
    (PO_QID,
     PI_CLIENT_ID,
     PI_CLORDID_CLIENT_ID,
     PO_CLORDID,
     PI_ORIGCLORDID,
     PI_SERIAL_NO,
     PI_QUOTETRANSTYPE,
     PI_ANONYMOUSINDICATOR,
     PI_SECURITYTYPE,
     PI_MARKETINDICATOR,
     PI_QUOTETYPE,
     PI_VALIDUNTILTIME,
     PI_SECURITYID,
     PI_SIDE,
     PI_MAXFLOOR,
     PI_MINTICKSIZE,
     PI_PRICE,
     PI_ORDERQTY,
     PI_SETTLTYPE,
     PI_CLEARINGMETHOD,
     PI_DELIVERYTYPE,
     PI_MATURITYYIELD,
     PI_STRIKEYIELD,
     PI_PARTYID,
     PI_TRADERID,
     PI_CASH_ACCT_NUMBER,
     PI_CUSTODIAN_ACCT_NUMBER,
     PI_CUSTODIAN_INSTITUTION_NAME,
     PI_SETTLCURRENCY,
     PI_SETTLCURRFXRATE,
     PI_REFERENCE,
     PI_TRADERNAME,
     PI_CONTINGENCYINDICATOR,
     PI_LEAVESQTY,
     PI_PRINCIPAL,
     PI_TOTALPRINCIPAL,
     PI_PARTYNAME,
     PI_CASH_BANK_NAME,
     0,
     PO_ERRORCODE,
     PO_ERRORMSG,
     PI_UPDATETIME,
     PI_ACTION,
	 PI_QUOTEID);

  IF PI_QUOTETRANSTYPE = 'N' THEN
    SELECT NEXTVAL('S_AUTOINC_CFETS_TRADE_QID') INTO V_QID FROM DUAL;
    INSERT INTO TTRD_CFETS_TRADE_CD
      (QID,
       CLIENT_ID,
       CLORDID_CLIENT_ID,
       CLORDID,
       QUOTETRANSTYPE,
       ANONYMOUSINDICATOR,
       SECURITYTYPE,
       MARKETINDICATOR,
       QUOTETYPE,
       VALIDUNTILTIME,
       SECURITYID,
       SIDE,
       MAXFLOOR,
       MINTICKSIZE,
       PRICE,
       ORDERQTY,
       SETTLTYPE,
       CLEARINGMETHOD,
       MATURITYYIELD,
       STRIKEYIELD,
       PARTYID,
       TRADERID,
       CASH_ACCT_NUMBER,
       CUSTODIAN_ACCT_NUMBER,
       CUSTODIAN_INSTITUTION_NAME,
       STATUS,
       ERRORCODE,
       ERRORMSG,
       UPDATETIME,
       PARTYNAME,
       TRADERNAME,
       SETTLCURRENCY,
       SETTLCURRFXRATE,
       REFERENCE,
       CONTINGENCYINDICATOR,
       LEAVESQTY,
       PRINCIPAL,
       TOTALPRINCIPAL,
       CASH_BANK_NAME,
       DELIVERYTYPE,
       ACT_QID,
       ACT_STATUS,
       ACT_ERRORCODE,
       ACT_ERRORMSG,
       SEND_RECV_FLAG,
       ACT_TYPE,
       ACTION)
    VALUES
      (V_QID,
       PI_CLIENT_ID,
       PI_CLORDID_CLIENT_ID,
       PO_CLORDID,
       PI_QUOTETRANSTYPE,
       PI_ANONYMOUSINDICATOR,
       PI_SECURITYTYPE,
       PI_MARKETINDICATOR,
       PI_QUOTETYPE,
       PI_VALIDUNTILTIME,
       PI_SECURITYID,
       PI_SIDE,
       PI_MAXFLOOR,
       PI_MINTICKSIZE,
       PI_PRICE,
       PI_ORDERQTY,
       PI_SETTLTYPE,
       PI_CLEARINGMETHOD,
       PI_MATURITYYIELD,
       PI_STRIKEYIELD,
       PI_PARTYID,
       PI_TRADERID,
       PI_CASH_ACCT_NUMBER,
       PI_CUSTODIAN_ACCT_NUMBER,
       PI_CUSTODIAN_INSTITUTION_NAME,
       0,
       PO_ERRORCODE,
       PO_ERRORMSG,
       PI_UPDATETIME,
       PI_PARTYNAME,
       PI_TRADERNAME,
       PI_SETTLCURRENCY,
       PI_SETTLCURRFXRATE,
       PI_REFERENCE,
       PI_CONTINGENCYINDICATOR,
       PI_LEAVESQTY,
       PI_PRINCIPAL,
       PI_TOTALPRINCIPAL,
       PI_CASH_BANK_NAME,
       PI_DELIVERYTYPE,
       PO_QID,
       0,
       PO_ERRORCODE,
       PO_ERRORMSG,
       'SEND',
       PI_QUOTETRANSTYPE,
       PI_ACTION);
  ELSEIF PI_QUOTETRANSTYPE = 'C' THEN
    UPDATE TTRD_CFETS_TRADE_CD
       SET ACT_STATUS    = 0,
           ACT_QID       = PO_QID,
           ACT_ERRORCODE = PO_ERRORCODE,
           ACT_ERRORMSG  = PO_ERRORMSG,
           ACT_TYPE      = PI_QUOTETRANSTYPE,
           UPDATETIME    = PI_UPDATETIME
     WHERE QUOTEID = PI_QUOTEID;
  END IF;
END;

