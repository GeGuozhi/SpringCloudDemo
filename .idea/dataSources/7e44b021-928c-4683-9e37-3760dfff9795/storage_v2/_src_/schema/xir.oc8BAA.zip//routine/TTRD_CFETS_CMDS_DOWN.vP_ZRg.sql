create
    definer = root@`%` procedure TTRD_CFETS_CMDS_DOWN()
BEGIN
DECLARE ROWCOUNT INT;
DECLARE SEQNUM INT;
DECLARE DATATYPE VARCHAR(10);

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_ABS_SERIES`
-- ----------------------------
CREATE TABLE IF NOT EXISTS TTRD_CMDS_ABS_SERIES (
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL,
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：7-交易品种行情',
  `BEG_DATE`                          CHAR(10)                       NOT NULL,
  `TRANSACTTIME`                      CHAR(8)                        DEFAULT NULL,
  `TRADEMETHOD`                       INT                            NOT NULL COMMENT '0 - ALL; 1 - NEGOTIATION; 2 - CLICK AND DEAL_LIMIT ORDER IN FX MARKET; 3 - MATCHING; 4 - REQUEST FOR QUOTE; 5 - ONE CLICK ',
  `I_CODE`                            VARCHAR(100)                    NOT NULL,
  `A_TYPE`                            VARCHAR(20)                    NOT NULL,
  `M_TYPE`                            VARCHAR(20)                    NOT NULL,
  `I_NAME`                            VARCHAR(50)                    DEFAULT NULL,
  `PRE_CLOSING_CLEANPRICE`            DECIMAL(14,8)                  DEFAULT NULL COMMENT '前收盘净价',
  `PRE_WEIGHTED_CLEANPRICE`           DECIMAL(14,8)                  DEFAULT NULL COMMENT '前加权平均净价',
  `OPENING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '开盘净价',
  `LATEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最新净价',
  `CHANGE_CLEANPRICE`                 DECIMAL(22,13)                 DEFAULT NULL COMMENT '涨跌幅',
  `HIGHEST_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '最高净价',
  `LOWEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最低净价',
  `CLOSING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '收盘净价',
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均净价',
  `PRE_CLOSING_YIELD`                 DECIMAL(12,8)                  DEFAULT NULL COMMENT '前收盘收益率',
  `PRE_WEIGHTED_YIELD`                DECIMAL(12,8)                  DEFAULT NULL COMMENT '前加权平均收益率',
  `OPENING_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '开盘收益率',
  `LATEST_YIELD`                      DECIMAL(12,8)                  DEFAULT NULL COMMENT '最新收益率',
  `HIGHEST_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '最高收益率',
  `LOWEST_YIELD`                      DECIMAL(12,8)                  DEFAULT NULL COMMENT '最低收益率',
  `CLOSING_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '收盘收益率',
  `WEIGHTED_YIELD`                    DECIMAL(12,8)                  DEFAULT NULL COMMENT '加权平均收益率',
  `TURNOVER`                          DECIMAL(38,6)                  DEFAULT NULL COMMENT '成交量',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='资产支持证券行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_BONDSERIES`
-- ----------------------------

CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BONDSERIES` (
  `BEG_DATE`                          CHAR(10)                       NOT NULL COMMENT ' 起始时间',
  `TRANSACTTIME`                      CHAR(8)                        DEFAULT NULL COMMENT '传输时间',
  `TRADEMETHOD`                       INT                            NOT NULL COMMENT '交易方式,0 - ALL; 1 - NEGOTIATION; 2 - CLICK AND DEAL_LIMIT ORDER IN FX MARKET; 3 - MATCHING; 4 - REQUEST FOR QUOTE; 5 - ONE CLICK ',
  `I_CODE`                            VARCHAR(100)                    NOT NULL COMMENT '债券代码',
  `A_TYPE`                            VARCHAR(20)                    NOT NULL,
  `M_TYPE`                            VARCHAR(20)                    NOT NULL,
  `I_NAME`                            VARCHAR(100)                   DEFAULT NULL COMMENT '债券名称',
  `PRE_CLOSING_CLEANPRICE`            DECIMAL(14,8)                  DEFAULT NULL COMMENT '前收盘净价',
  `PRE_WEIGHTED_CLEANPRICE`           DECIMAL(14,8)                  DEFAULT NULL COMMENT '前加权平均净价',
  `OPENING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '开盘净价',
  `LATEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最新净价',
  `CHANGE_CLEANPRICE`                 DECIMAL(22,13)                  DEFAULT NULL COMMENT '涨跌幅',
  `HIGHEST_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '最高净价',
  `LOWEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最低净价',
  `CLOSING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '收盘净价',
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均净价',
  `PRE_CLOSING_YIELD`                 DECIMAL(12,8)                  DEFAULT NULL COMMENT '前收盘收益率',
  `PRE_WEIGHTED_YIELD`                DECIMAL(12,8)                  DEFAULT NULL COMMENT '前加权平均收益率',
  `OPENING_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '开盘收益率',
  `LATEST_YIELD`                      DECIMAL(12,8)                  DEFAULT NULL COMMENT '最新收益率',
  `HIGHEST_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '最高收益率',
  `LOWEST_YIELD`                      DECIMAL(12,8)                  DEFAULT NULL COMMENT '最低收益率',
  `CLOSING_YIELD`                     DECIMAL(12,8)                  DEFAULT NULL COMMENT '收盘收益率',
  `WEIGHTED_YIELD`                    DECIMAL(12,8)                  DEFAULT NULL COMMENT '加权平均收益率',
  `TURNOVER`                          DECIMAL(38,6)                  DEFAULT NULL COMMENT '成交量（百万）',
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：7-交易品种行情，37-存款类机构行情，8-回购利率市场行情，0-成交行情',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新时间',
  KEY `IDX_BEG_DATE_TRANSACTTIME` (`BEG_DATE`,`TRANSACTTIME`)
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券交易品种行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_CR_SERIES`
-- ----------------------------

CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES` (
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL,
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：7-交易品种行情，37-存款类机构行情，8-回购利率市场行情，0-成交行情',
  `MARKETINDICATOR`                   VARCHAR(50)                    DEFAULT NULL COMMENT '市场标识',
  `BEG_DATE`                          CHAR(10)                       NOT NULL,
  `TRANSACTTIME`                      CHAR(21)                       DEFAULT NULL,
  `TRADEMETHOD`                       INT                            DEFAULT NULL COMMENT '0 - ALL; 1 - NEGOTIATION; 2 - CLICK AND DEAL_LIMIT ORDER IN FX MARKET; 3 - MATCHING; 4 - REQUEST FOR QUOTE; 5 - ONE CLICK ',
  `SECURITYID`                        VARCHAR(100)                   NOT NULL,
  `SYMBOL`                            VARCHAR(50)                    DEFAULT NULL,
  `PRE_CLOSING_CLEANPRICE`            DECIMAL(14,8)                  DEFAULT NULL COMMENT '前收盘利率',
  `PRE_WEIGHTED_CLEANPRICE`           DECIMAL(14,8)                  DEFAULT NULL COMMENT '前加权平均利率',
  `OPENING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '开盘利率',
  `LATEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最新利率',
  `HIGHEST_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '最高利率',
  `LOWEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最低利率',
  `CLOSING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '收盘利率',
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均利率',
  `WEIGHTED_YIELD_IR`                 DECIMAL(38,6)                  DEFAULT NULL COMMENT '加权平均利率（利率债）',
  `TURNOVER`                          DECIMAL(38,6)                  DEFAULT NULL COMMENT '成交量',
  `AVGTERM`                           VARCHAR(50)                    DEFAULT NULL COMMENT '平均期限',
  `TRANSACTIONNUM`                    INT                            DEFAULT NULL COMMENT '成交笔数',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='质押式回购行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_CR_SERIES_INST`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_INST` (
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL,
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：45-分机构类型盘中行情数据',
  `MARKETINDICATOR`                   VARCHAR(50)                    DEFAULT NULL COMMENT '市场标识',
  `BEG_DATE`                          CHAR(10)                       NOT NULL,
  `TRANSACTTIME`                      CHAR(21)                       NOT NULL,
  `SECURITYID`                        VARCHAR(100)                    DEFAULT NULL,
  `SYMBOL`                            VARCHAR(50)                    DEFAULT NULL,
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均利率',
  `PARTYID`                      	  VARCHAR(50)                    DEFAULT NULL COMMENT '机构展示类型',
  `DIRECTION`                      	  CHAR(1)                        DEFAULT NULL COMMENT '交易方向',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='质押式回购分机构类型盘中行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_EXECUTIONREPORT`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_EXECUTIONREPORT` (
  `EPID`                              DECIMAL(16,0)                  NOT NULL,
  `TRDDATE`                           CHAR(10)                       DEFAULT NULL COMMENT '委托日期',
  `TRDTIME`                           CHAR(8)                        DEFAULT NULL COMMENT '委托时间',
  `EXECID`                            VARCHAR(50)                    DEFAULT NULL COMMENT '交易序号',
  `TRDTYPE`                           VARCHAR(10)                    DEFAULT NULL COMMENT '交易类别',
  `MARKETINDICATOR`                   INT                            DEFAULT NULL COMMENT '1 -INTER BANK OFFERING; 2 -INTEREST RATE SWAP; 3 -FORWARD RATE AGREEMENT ;4 -CASH BOND ;5 -BOND FORWARD ;6 -ASSET BACKED SECURITY; 7 -ETFS ; 8 -SECURITY LENDING; 9 -COLLATERAL REPO ;10 -OUTRIGHT REPO;11-FXSWP;12-FXSPT;13-FXNDF;14-FXFOW ;15-FXIRS;16 - BENCHMARK;17-FXCRS',
  `DIRCTION`                          CHAR(1)                        DEFAULT NULL COMMENT '1-买入 / 拆入 / 融入 / 逆回购/固定支付/参考利率1支付; 4-卖出 / 拆出 / 融出 / 正回购/固定收取/参考利率1收取; B-多端交易产品如双边报价使用此值，每端（LEG）分别定义交易方向，具体参考LEGSIDE定义; H-买-卖; I-卖-买',
  `I_CODE`                            VARCHAR(100)                    DEFAULT NULL COMMENT '金融工具代码',
  `A_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '资产类型',
  `M_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '市场类型',
  `I_NAME`                            VARCHAR(60)                    DEFAULT NULL COMMENT '金融工具名称',
  `U_I_CODE`                          VARCHAR(200)                   DEFAULT NULL COMMENT '浮动利率曲线名称',
  `U_A_TYPE`                          VARCHAR(20)                    DEFAULT NULL,
  `U_M_TYPE`                          VARCHAR(20)                    DEFAULT NULL,
  `U_I_NAME`                          VARCHAR(60)                    DEFAULT NULL COMMENT '金融工具名称',
  `PRICE`                             DECIMAL(14,8)                  DEFAULT NULL COMMENT '交易价格',
  `YTM`                               DECIMAL(12,8)                  DEFAULT NULL,
  `TRDFV`                             DECIMAL(38,6)                  DEFAULT NULL COMMENT '交易数量',
  `TRDCASHAMT`                        DECIMAL(38,6)                  DEFAULT NULL COMMENT '交易金额',
  `U_CLEAR_PRICE`                     DECIMAL(14,8)                  DEFAULT NULL,
  `U_CLEAR_PRICE2`                    DECIMAL(14,8)                  DEFAULT NULL,
  `U_YTM`                             DECIMAL(12,8)                  DEFAULT NULL,
  `U_YTM2`                            DECIMAL(12,8)                  DEFAULT NULL,
  `TRADELIMITDAYS`                    INT                            DEFAULT NULL,
  `SETTLCURRAMT`                      DECIMAL(38,6)                  DEFAULT NULL,
  `SETTLCURRAMT2`                     DECIMAL(38,6)                  DEFAULT NULL,
  `EXECTYPE`                          VARCHAR(10)                    DEFAULT NULL COMMENT 'F- 成交; H - 撤销; 5 - 更新; F-成交;H-撤销;5-更新;101-应急',
  `FRA_TRADEFWDDAYS`                  INT                            DEFAULT NULL,
  `BND_TRDTYPE`                       INT                            DEFAULT NULL COMMENT '1-非做市; 2-做市; 4-买方做市; 5-卖方做市',
  `IRS_BENCHMARK2`                    VARCHAR(100)                   DEFAULT NULL,
  `IRS_BENCHMARKSPREAD2`              DECIMAL(14,8)                  DEFAULT NULL,
  `IRS_BENCHMARK1`                    VARCHAR(100)                   DEFAULT NULL,
  `IRS_BENCHMARKSPREAD1`              DECIMAL(14,8)                  DEFAULT NULL,
  `IRS_RATE`                          DECIMAL(14,8)                  DEFAULT NULL,
  `PRINCIPAL`                         DECIMAL(32,8)                  DEFAULT NULL COMMENT '每百元本金额',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL,
  PRIMARY KEY (`EPID`),
  KEY `IDX_TTRD_CMDS_EXECUTIONREPORT` (`EXECID`, `EXECTYPE`)
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='CMDS成交数据';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_IBLB_SERIES`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IBLB_SERIES` (
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL,
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：7-交易品种行情，37-存款类机构行情，8-回购利率市场行情，0-成交行情',
  `MARKETINDICATOR`                   VARCHAR(50)                    DEFAULT NULL COMMENT '市场标识',
  `BEG_DATE`                          CHAR(10)                       NOT NULL,
  `TRANSACTTIME`                      CHAR(21)                       DEFAULT NULL,
  `SECURITYID`                        VARCHAR(100)                    NOT NULL,
  `SYMBOL`                            VARCHAR(50)                    DEFAULT NULL,
  `PRE_CLOSING_CLEANPRICE`            DECIMAL(14,8)                  DEFAULT NULL COMMENT '前收盘利率',
  `PRE_WEIGHTED_CLEANPRICE`           DECIMAL(14,8)                  DEFAULT NULL COMMENT '前加权平均利率',
  `OPENING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '开盘利率',
  `LATEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最新利率',
  `HIGHEST_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '最高利率',
  `LOWEST_CLEANPRICE`                 DECIMAL(14,8)                  DEFAULT NULL COMMENT '最低利率',
  `CLOSING_CLEANPRICE`                DECIMAL(14,8)                  DEFAULT NULL COMMENT '收盘利率',
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均利率',
  `TURNOVER`                          DECIMAL(38,6)                  DEFAULT NULL COMMENT '成交量',
  `AVGTERM`                           VARCHAR(50)                    DEFAULT NULL COMMENT '平均期限',
  `TRANSACTIONNUM`                    INT                            DEFAULT NULL COMMENT '成交笔数',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='信用拆借行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_IBLB_SERIES_INST`
-- ----------------------------


CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IBLB_SERIES_INST` (
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL,
  `MDSUBTYPE`                         INT                            DEFAULT NULL COMMENT '市场行情类型：45-分机构类型盘中行情数据',
  `MARKETINDICATOR`                   VARCHAR(50)                    DEFAULT NULL COMMENT '市场标识',
  `BEG_DATE`                          CHAR(10)                       NOT NULL,
  `TRANSACTTIME`                      CHAR(21)                       NOT NULL,
  `SECURITYID`                        VARCHAR(100)                    DEFAULT NULL,
  `SYMBOL`                            VARCHAR(50)                    DEFAULT NULL,
  `WEIGHTED_CLEANPRICE`               DECIMAL(14,8)                  DEFAULT NULL COMMENT '加权平均利率',
  `PARTYID`                           VARCHAR(50)                    DEFAULT NULL COMMENT '机构展示类型',
  `DIRECTION`                         CHAR(1)                        DEFAULT NULL COMMENT '交易方向',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='信用拆借分机构类型盘中行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_IRS_XSWAP_BESTQUOTE`
-- ----------------------------


CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSWAP_BESTQUOTE` (
  `TRANSACTTIME`                      VARCHAR(30)                    DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                         DECIMAL(10,0)                  DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                   VARCHAR(30)                    NOT NULL COMMENT '2-利率互换',
  `TRADEMETHOD`                       DECIMAL(10,0)                  DEFAULT NULL COMMENT '3-匿名点击',
  `SECURITYID`                        VARCHAR(100)                    NOT NULL COMMENT '合约品种',
  `BID_PX`                            VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME`                   VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `ASK_PX`                            VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME`                   VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='最优报价行情-XSWAP';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_IRS_XSWAP_DEPTHQUOTE`
-- ----------------------------



CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSWAP_DEPTHQUOTE` (
  `TRANSACTTIME`                      VARCHAR(30)                    DEFAULT NULL COMMENT '报价深度行情的更新时间',
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                         DECIMAL(10,0)                  DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                   VARCHAR(30)                    NOT NULL COMMENT '2-利率互换',
  `TRADEMETHOD`                       DECIMAL(10,0)                  DEFAULT NULL COMMENT '3-匿名点击',
  `SECURITYID`                        VARCHAR(100)                    NOT NULL COMMENT '合约品种',
  `MDBOOKTYPE`                        DECIMAL(10,0)                  DEFAULT NULL COMMENT '价格深度',
  `MARKETDEPTH`                       DECIMAL(10,0)                  DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
  `BID_PX1`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME1`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `BID_PX2`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME2`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `BID_PX3`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME3`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `BID_PX4`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME4`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `BID_PX5`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME5`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `ASK_PX1`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME1`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `ASK_PX2`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME2`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `ASK_PX3`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME3`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `ASK_PX4`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME4`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `ASK_PX5`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME5`                  VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='深度行情-XSWAP';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_IRS_XSWAP_TRADEQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSWAP_TRADEQUOTE` (
  `TRANSACTTIME`                      VARCHAR(30)                    DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                         DECIMAL(10,0)                  DEFAULT NULL COMMENT '0-成交行情',
  `MARKETINDICATOR`                   VARCHAR(30)                    NOT NULL COMMENT '2-利率互换',
  `TRADEMETHOD`                       DECIMAL(10,0)                  DEFAULT NULL COMMENT '3-匿名点击',
  `SECURITYID`                        VARCHAR(100)                    NOT NULL COMMENT '合约品种',
  `LASTRATE`                          VARCHAR(30)                    DEFAULT NULL COMMENT '最新利率',
  `TRADEVOLUME`                       VARCHAR(30)                    DEFAULT NULL COMMENT '最新成交量',
  `OPENRATE`                          VARCHAR(30)                    DEFAULT NULL COMMENT '开盘利率',
  `HIGHESTRATE`                       VARCHAR(30)                    DEFAULT NULL COMMENT '最高利率',
  `LOWESTRATE`                        VARCHAR(30)                    DEFAULT NULL COMMENT '最低利率',
  `INTRADAYREFERENCEPRICE`            VARCHAR(30)                    DEFAULT NULL COMMENT '盘中参考价',
  `CUMULATIVEVOLUME`                  VARCHAR(30)                    DEFAULT NULL COMMENT '当日累计成交量',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='成交行情-XSWAP';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_QUOTE_CLICKDEAL`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_QUOTE_CLICKDEAL` (
  `QID`                               DECIMAL(16,0)                  NOT NULL COMMENT '序号',
  `QUOTEDATE`                         CHAR(10)                       DEFAULT NULL COMMENT '报价日期',
  `QUOTETIME`                         CHAR(8)                        DEFAULT NULL COMMENT '报价时间',
  `QUOTEID`                           VARCHAR(30)                    DEFAULT NULL COMMENT '报价编号',
  `TRANSACTTIME`                      VARCHAR(21)                    DEFAULT NULL COMMENT '处理时间',
  `I_CODE`                            VARCHAR(100)                    DEFAULT NULL COMMENT '金融工具代码',
  `A_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '资产类型',
  `M_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '市场类型',
  `I_NAME`                            VARCHAR(30)                    DEFAULT NULL COMMENT '金融工具名称',
  `VALIDTIME`                         VARCHAR(21)                    DEFAULT NULL COMMENT '报价有效时间',
  `DIRCTION`                          VARCHAR(1)                     DEFAULT NULL COMMENT '1-买入 / 拆入 / 融入 / 逆回购/固定支付/参考利率1支付 4-卖出 / 拆出 / 融出 / 正回购/固定收取/参考利率1收取 B-多端交易产品如双边报价使用此值，每端（LEG）分别定义交易方向，具体参考LEGSIDE定义。 H-买-卖 I-卖-买',
  `MARKETINDICATOR`                   VARCHAR(10)                    DEFAULT NULL COMMENT '报价市场',
  `ANONYMOUS_INDICATOR`               VARCHAR(1)                     DEFAULT NULL COMMENT '匿名',
  `QUOTETYPE`                         INT                            DEFAULT NULL COMMENT '报价类别',
  `CONTINGENCY_INDICATOR`             VARCHAR(1)                     DEFAULT NULL COMMENT '应急标识',
  `MINQTY`                            DECIMAL(32,6)                  DEFAULT NULL COMMENT '最小成交券面总额',
  `MAXQTY`                            DECIMAL(32,6)                  DEFAULT NULL COMMENT '最大成交券面总额',
  `MAXFLOOR`                          DECIMAL(32,6)                  DEFAULT NULL COMMENT '最大显示券面总额',
  `MINTICKSIZE`                       DECIMAL(32,6)                  DEFAULT NULL COMMENT '最小变动单位',
  `PRICE`                             DECIMAL(32,8)                  DEFAULT NULL COMMENT '净价',
  `YIELD`                             DECIMAL(32,12)                 DEFAULT NULL COMMENT '到期收益率',
  `STRIKE_YIELD`                      DECIMAL(32,12)                 DEFAULT NULL COMMENT '行权收益率',
  `FV_TOTALAMT`                       DECIMAL(32,6)                  DEFAULT NULL COMMENT '券面总额',
  `TRDCASHAMT`                        DECIMAL(32,6)                  DEFAULT NULL COMMENT '交易金额',
  `SETTLTYPE`                         VARCHAR(10)                    DEFAULT NULL COMMENT '清算速度',
  `AI`                                DECIMAL(32,12)                 DEFAULT NULL COMMENT '应计利息',
  `DIRTY_PRICE`                       DECIMAL(32,8)                  DEFAULT NULL COMMENT '全价',
  `AI_TOTALAMT`                       DECIMAL(32,8)                  DEFAULT NULL COMMENT '应计利息总额',
  `SETTLCURRAMT`                      DECIMAL(32,6)                  DEFAULT NULL COMMENT '结算金额',
  `LASTQTY`                           DECIMAL(32,6)                  DEFAULT NULL COMMENT '已成交券面金额',
  `INITIATOR`                         VARCHAR(50)                    DEFAULT NULL COMMENT '报价方',
  `TRADER`                            VARCHAR(50)                    DEFAULT NULL COMMENT '本方交易员',
  `INITIATOR_NAME`                    VARCHAR(200)                   DEFAULT NULL COMMENT '报价方名称',
  `REMARK`                            TEXT                           COMMENT '备注',
  `STATUS`                            INT                            DEFAULT NULL COMMENT '状态: 5 - 拒绝 16-正常 17-收到 18-发出 19- 撤销',
  `SETTLEMENT`                        VARCHAR(100)                   DEFAULT NULL COMMENT '结算方式，多个，中间用'',''隔开',
  `TRADELIMITDAYS`                    INT                            DEFAULT NULL COMMENT '合约期限',
  `BENCHMARK`                         VARCHAR(50)                    DEFAULT NULL COMMENT '参考利率',
  `SPREAD`                            DECIMAL(14,8)                  DEFAULT NULL COMMENT '利差',
  `BENCHMARK2`                        VARCHAR(50)                    DEFAULT NULL COMMENT '参考利率2',
  `SPREAD2`                           DECIMAL(14,8)                  DEFAULT NULL COMMENT '利差2',
  `STARTDATE`                         VARCHAR(10)                    DEFAULT NULL COMMENT '起息日',
  `ENDDATE`                           VARCHAR(10)                    DEFAULT NULL COMMENT '到期日',
  `QUOTE_TRANS_TYPE`                  VARCHAR(10)                    DEFAULT NULL COMMENT '报价报文会话类型,N--新增,R--修改,C--撤销,1--询价,2--拒绝,Q--快速撤单',
  `TRADETYPE`                         INT                            DEFAULT NULL COMMENT '成交类别',
  `REMARK_INDICATOR`                  VARCHAR(10)                    DEFAULT NULL COMMENT '有无备注',
  `LEAVES_TOTAL_QTY`                  VARCHAR(10)                    DEFAULT NULL COMMENT '未成交量',
  `DISPLAYQTY`                        VARCHAR(10)                    DEFAULT NULL COMMENT '可成交量',
  `PARTYID`                           VARCHAR(50)                    DEFAULT NULL COMMENT '机构展示类型',
  `SHORT_LEGAL_CHINESE_NAME`          VARCHAR(50)                    DEFAULT NULL COMMENT '会员中文简称',
  `PRINCIPAL`                         DECIMAL(32,8)                  DEFAULT NULL COMMENT '每百元本金额',
  `PRINCIPAL_TOTALAMT`                DECIMAL(32,8)                  DEFAULT NULL COMMENT '当前本金额',
  `DELIVERYTYPE`                      INT                            DEFAULT NULL COMMENT '首期结算方式(0 - DVP;4 - PUD;5 - DUP;6 - BVB;7-NONE)',
  `DELIVERYTYPE2`                     INT                            DEFAULT NULL COMMENT '到期结算方式(0 - DVP;4 - PUD;5 - DUP;6 - BVB;7-NONE)',
  `FRA_INTERESTFIXDATE`               CHAR(10)                       DEFAULT NULL COMMENT '远期协议利率确定日',
  `TRADEFWDDAYS`                      VARCHAR(10)                    DEFAULT NULL COMMENT '期限',
  `SETTLDATE`                         VARCHAR(10)                    DEFAULT NULL COMMENT '结算日',
  `BENCHMARK_CURVE_NAME`              VARCHAR(50)                    DEFAULT NULL COMMENT '浮动利率曲线名称',
  `BENCHMARKSPREAD`                   DECIMAL(14,8)                  DEFAULT NULL COMMENT '参考利率取值1',
  `BENCHMARKSPREAD2`                  DECIMAL(14,8)                  DEFAULT NULL COMMENT '参考利率取值2',
  `ROUTINGTYPE`                       INT                            DEFAULT NULL COMMENT '发送范围类型,1--目标对手方,2--目标对手方列表 多个,5--所有市场参与者,100--分层市场,101--国际市场全体成员,102--国际市场成员列表',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL,
  `ORDERQTY`                          DECIMAL(32,6)                  DEFAULT NULL COMMENT '券面总额合计',
  PRIMARY KEY (`QID`),
  KEY `IDX_TTRD_CMDS_QUOTE_CLICKDEAL` (`QUOTEID`, `TRANSACTTIME`, `INITIATOR`, `STATUS`)
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='本方点击成交报价';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_QUOTE_IRSWAPLEG`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_QUOTE_IRSWAPLEG` (
  `QID`                               DECIMAL(16,0)                  NOT NULL,
  `QUOTEID`                           VARCHAR(30)                    DEFAULT NULL,
  `LEGPRICETYPE`                      INT                            DEFAULT NULL,
  `LEGPRICE`                          DECIMAL(14,8)                  DEFAULT NULL,
  `LEGBENCHMARKCURVENAME`             VARCHAR(50)                    DEFAULT NULL,
  `LEGBENCHMARKSPREAD`                DECIMAL(14,8)                  DEFAULT NULL,
  `LEGDIR`                            CHAR(1)                        NOT NULL COMMENT '1-收 ； 2-付',
  `LEGTYPE`                           CHAR(1)                        DEFAULT NULL COMMENT '1-固定 2-浮动',
  `IMP_TIME`                          TIMESTAMP                      NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=UTF8;

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_QUOTE_MAKEMARKET`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_QUOTE_MAKEMARKET` (
  `QID`                               DECIMAL(16,0)                  NOT NULL,
  `QUOTEDATE`                         CHAR(10)                       DEFAULT NULL COMMENT '委托日期',
  `QUOTETIME`                         CHAR(8)                        DEFAULT NULL COMMENT '委托时间',
  `QUOTEID`                           VARCHAR(50)                    DEFAULT NULL COMMENT '交易序号',
  `MARKETINDICATOR`                   INT                            DEFAULT NULL COMMENT '1 -INTER BANK OFFERING; 2 -INTEREST RATE SWAP; 3 -FORWARD RATE AGREEMENT ;4 -CASH BOND ;5 -BOND FORWARD ;6 -ASSET BACKED SECURITY; 7 -ETFS ; 8 -SECURITY LENDING; 9 -COLLATERAL REPO ;10 -OUTRIGHT REPO;11-FXSWP;12-FXSPT;13-FXNDF;14-FXFOW ; 15-FXIRS;16 - BENCHMARK;17-FXCRS',
  `DIRCTION`                          CHAR(1)                        DEFAULT NULL COMMENT '1-买入 / 拆入 / 融入 / 逆回购/固定支付/参考利率1支付; 4-卖出 / 拆出 / 融出 / 正回购/固定收取/参考利率1收取; B-多端交易产品如双边报价使用此值，每端（LEG）分别定义交易方向，具体参考LEGSIDE定义; H-买-卖; I-卖-买',
  `I_CODE`                            VARCHAR(100)                    DEFAULT NULL COMMENT '金融工具代码',
  `A_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '资产类型',
  `M_TYPE`                            VARCHAR(20)                    DEFAULT NULL COMMENT '市场类型',
  `I_NAME`                            VARCHAR(60)                    DEFAULT NULL COMMENT '金融工具名称',
  `B_TRDFV`                           DECIMAL(38,6)                  DEFAULT NULL COMMENT '券面总额（买）',
  `B_PRICE`                           DECIMAL(14,8)                  DEFAULT NULL COMMENT '净价（买）',
  `B_YTM`                             DECIMAL(12,8)                  DEFAULT NULL COMMENT '到期收益率（买）',
  `B_SETTLTYPE`                       INT                            DEFAULT NULL COMMENT '清算速度（买）0--正常，1--T+0，2--T+1，3--T+2，4--T+3，5--T+4',
  `B_LEAVESTRDFV`                     DECIMAL(38,6)                  DEFAULT NULL COMMENT '未成交量（买）',
  `S_TRDFV`                           DECIMAL(38,6)                  DEFAULT NULL COMMENT '券面总额（卖）',
  `S_PRICE`                           DECIMAL(14,8)                  DEFAULT NULL COMMENT '净价（卖）',
  `S_YTM`                             DECIMAL(12,8)                  DEFAULT NULL COMMENT '到期收益率（卖）',
  `S_SETTLTYPE`                       INT                            DEFAULT NULL COMMENT '清算速度（卖）0--正常，1--T+0，2--T+1，3--T+2，4--T+3，5--T+4',
  `S_LEAVESTRDFV`                     DECIMAL(38,6)                  DEFAULT NULL COMMENT '未成交量（卖）',
  `INITIATOR`                         VARCHAR(30)                    DEFAULT NULL COMMENT '会员机构代码',
  `TRADER`                            VARCHAR(60)                    DEFAULT NULL COMMENT '发起方交易员',
  `INITIATOR_NAME`                    VARCHAR(200)                   DEFAULT NULL COMMENT '会员中文简称',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新日期',
  `STATUS`                            INT                            DEFAULT NULL COMMENT '报价状态 5--拒绝，16--正常，17--收到，18--发出，19--撤销，20--应急，21--过期',
  `QUOTE_TRANS_TYTPE`                 CHAR(2)                        DEFAULT NULL COMMENT '报价作类型，N-新增，C-撤销，R-修改，1-COUNTER，2-REJECT，Q-快速撤单，3-REPEAT',
  `TRANSACTTIME`                      VARCHAR(21)                    DEFAULT NULL COMMENT '业务发生时间',
  `BUY_DELIVERYOPTION`                CHAR(2)                        DEFAULT NULL COMMENT '结算方式（买），0-券款对付,4-见券付款,5-见款付券,6-券券对付,7-纯券过户,8-返券付费解券,9-券费对付,A-纯款过户,B-净额券款对付',
  `SELL_DELIVERYOPTION`               CHAR(2)                        DEFAULT NULL COMMENT '结算方式（卖），0-券款对付,4-见券付款,5-见款付券,6-券券对付,7-纯券过户,8-返券付费解券,9-券费对付,A-纯款过户,B-净额券款对付',
  `B_DISPLAYTRDFV`                    DECIMAL(38,6)                  DEFAULT NULL COMMENT '显示的数量，在冰山订单中用于表示“可成交量”(买)',
  `S_DISPLAYTRDFV`                    DECIMAL(38,6)                  DEFAULT NULL COMMENT '显示的数量，在冰山订单中用于表示“可成交量”(卖)',
  PRIMARY KEY (`QID`),
  KEY `IDX_CMDS_QUOTE_QUOTEID` (`QUOTEID`),
  KEY `IDX_QUOTEDATE_QUOTETIME` (`QUOTEDATE`,`QUOTETIME`)
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='CMDS做市报价';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SBFWD_BESTQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SBFWD_BESTQUOTE` (
  `TRANSACTTIME`                      VARCHAR(30)                    DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                            VARCHAR(30)                    DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                         DECIMAL(10,0)                  DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                   VARCHAR(30)                    NOT NULL COMMENT '43-标准债券远期',
  `TRADEMETHOD`                       DECIMAL(10,0)                  DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                    DECIMAL(10,0)                  DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                        VARCHAR(100)                    NOT NULL COMMENT '合约品种',
  `BID_PX`                            VARCHAR(30)                    DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME`                   VARCHAR(30)                    DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE`                       VARCHAR(30)                    DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_NUMBEROFORDERS`                DECIMAL(10,0)                  DEFAULT NULL COMMENT '同X-TRADE系统实现',
  `ASK_PX`                            VARCHAR(30)                    DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME`                   VARCHAR(30)                    DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE`                       VARCHAR(30)                    DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_NUMBEROFORDERS`                DECIMAL(10,0)                  DEFAULT NULL COMMENT '同X-TRADE系统实',
  `UPDATETIME`                        VARCHAR(30)                    DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准债券远期最优行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SBFWD_DEPTHQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SBFWD_DEPTHQUOTE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报价深度行情的更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '43-标准债券远期',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                   DECIMAL(10,0)                   DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT 'SECURITYID',
  `MDBOOKTYPE`                       DECIMAL(10,0)                   DEFAULT NULL COMMENT '价格深度',
  `MARKETDEPTH`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
  `BID_PX1`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX2`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX3`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX4`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX1`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX2`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX3`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX4`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准债券远期深度行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SBFWD_SETTLEDPRICE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SBFWD_SETTLEDPRICE` (
  `BENCHMARKEFFECTIVEDATE`           VARCHAR(30)                     DEFAULT NULL COMMENT '日期，格式为：YYYYMMDD',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '43-标准债券远期',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '40-每日结算价',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT '合约品种',
  `SETTLEDPRICE`                     VARCHAR(30)                     DEFAULT NULL COMMENT '每日结算利率',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准债券远期每日结算价';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SBFWD_TRADEQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SBFWD_TRADEQUOTE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '0-成交行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '43-标准债券远期',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                   DECIMAL(10,0)                   DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT '合约品种',
  `OPENPRICE`                        VARCHAR(30)                     DEFAULT NULL COMMENT '开盘价格',
  `HIGHESTPRICE`                     VARCHAR(30)                     DEFAULT NULL COMMENT '最高价格',
  `LOWESTPRICE`                      VARCHAR(30)                     DEFAULT NULL COMMENT '最低价格',
  `LASTPRICE`                        VARCHAR(30)                     DEFAULT NULL COMMENT '最新价格',
  `TRADEVOLUME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '最新成交量',
  `CUMULATIVEVOLUME`                 VARCHAR(30)                     DEFAULT NULL COMMENT '当日累计成交量',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准债券远期成交行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SIRS_BESTQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SIRS_BESTQUOTE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '42-标准利率互换',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                   DECIMAL(10,0)                   DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT '合约品种',
  `BID_PX`                           VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME`                  VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE`                      VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_NUMBEROFORDERS`               DECIMAL(10,0)                   DEFAULT NULL COMMENT '同X-TRADE系统实现',
  `ASK_PX`                           VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME`                  VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE`                      VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_NUMBEROFORDERS`               DECIMAL(10,0)                   DEFAULT NULL COMMENT '同X-TRADE系统实',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准利率互换最优行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SIRS_DEPTHQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SIRS_DEPTHQUOTE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报价深度行情的更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '42-标准利率互换',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                   DECIMAL(10,0)                   DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT 'SECURITYID',
  `MDBOOKTYPE`                       DECIMAL(10,0)                   DEFAULT NULL COMMENT '价格深度',
  `MARKETDEPTH`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
  `BID_PX1`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX2`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX3`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX4`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `BID_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX1`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX2`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX3`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX4`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `ASK_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `ASK_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `ASK_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT 'C-OCO，当订单为非OCO，则不传输该域',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准利率互换深度行情';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SIRS_SETTLEDPRICE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SIRS_SETTLEDPRICE` (
  `BENCHMARKEFFECTIVEDATE`           VARCHAR(30)                     DEFAULT NULL COMMENT '日期，格式为：YYYYMMDD',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '42-标准利率互换',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '40-每日结算价',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT '合约品种',
  `SETTLEDPRICE`                     VARCHAR(30)                     DEFAULT NULL COMMENT '每日结算利率',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准利率互换每日结算价';

-- ----------------------------
-- TABLE STRUCTURE FOR `TTRD_CMDS_SIRS_TRADEQUOTE`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SIRS_TRADEQUOTE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '0-成交行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     NOT NULL COMMENT '42-标准利率互换',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `CLEARINGMETHOD`                   DECIMAL(10,0)                   DEFAULT NULL COMMENT '13-双边自行清算，6-上海清算所清算',
  `SECURITYID`                       VARCHAR(100)                     NOT NULL COMMENT '合约品种',
  `OPENPRICE`                        VARCHAR(30)                     DEFAULT NULL COMMENT '开盘价格',
  `HIGHESTPRICE`                     VARCHAR(30)                     DEFAULT NULL COMMENT '最高价格',
  `LOWESTPRICE`                      VARCHAR(30)                     DEFAULT NULL COMMENT '最低价格',
  `LASTPRICE`                        VARCHAR(30)                     DEFAULT NULL COMMENT '最新价格',
  `TRADEVOLUME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '最新成交量',
  `CUMULATIVEVOLUME`                 VARCHAR(30)                     DEFAULT NULL COMMENT '当日累计成交量',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='标准利率互换成交行情';

CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_BESTPRICE` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '行情更新时间',
  `MDTYPE`                           VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10,0)                   DEFAULT NULL COMMENT '38-报价行情',
  `MARKETINDICATOR`                  VARCHAR(30)                     DEFAULT NULL COMMENT '9-质押式回购',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `ASK_PX`                   		 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `SECURITYID`                       VARCHAR(100)                    NOT NULL COMMENT '合约名称',
  `SYMBOL`                           VARCHAR(50)                     DEFAULT NULL COMMENT '合约品种',
  `ASK_TRADEVOLUME`                  VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE`                      VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `ASK_NUMBEROFORDERS`               VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单笔数',
  `BID_PX`                      	 VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME`                  VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE`                      VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `BID_NUMBEROFORDERS`               VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单笔数',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='最优报价行情-X-REPO';



CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_DEPTH` (
  `TRANSACTTIME`                     VARCHAR(30)                     DEFAULT NULL COMMENT '行情更新时间',
  `MARKETINDICATOR`                  VARCHAR(30)                     DEFAULT NULL COMMENT '9-质押式回购',
  `TRADEMETHOD`                      DECIMAL(10,0)                   DEFAULT NULL COMMENT '3-匿名点击',
  `SECURITYID`                       VARCHAR(100)                    NOT NULL COMMENT '合约名称',
  `MDTYPE`                      	 VARCHAR(30)                     DEFAULT NULL COMMENT 'R-人民币市场行情',
  `MDSUBTYPE`                        DECIMAL(10)                     DEFAULT NULL COMMENT '价格深度',
  `MDBOOKTYPE`                       DECIMAL(10)                     DEFAULT NULL COMMENT '38-报价行情',
  `MARKETDEPTH`                      DECIMAL(10)                     DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
  `SYMBOL`                  		 VARCHAR(50)                     DEFAULT NULL COMMENT '交易品种',
  `ASK_PX1`                  		 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `ASK_PX2`                      	 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `ASK_PX3`               			 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `ASK_PX4`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `ASK_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报卖价',
  `ASK_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报卖量',
  `ASK_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报卖订单类型',
  `BID_PX1`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME1`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE1`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `BID_PX2`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME2`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE2`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `BID_PX3`                      	 VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME3`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE3`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `BID_PX4`                      	 VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME4`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE4`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `BID_PX5`                          VARCHAR(30)                     DEFAULT NULL COMMENT '报买价',
  `BID_TRADEVOLUME5`                 VARCHAR(30)                     DEFAULT NULL COMMENT '报买量',
  `BID_ORDTYPE5`                     VARCHAR(30)                     DEFAULT NULL COMMENT '报买订单类型',
  `UPDATETIME`                       VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='报价深度行情-X-REPO';


CREATE TABLE IF NOT EXISTS `TIR_SERIES_AVERAGESHIBOR` (
  `BENCHMARK_EFFECTIVE_DATE`        VARCHAR(30)                     DEFAULT NULL COMMENT '均值生成日期',
  `MDTYPE`                          VARCHAR(30)                     DEFAULT NULL COMMENT 'SHIBOR均值',
  `SHIBOR_AVE_TYPE`                 DECIMAL(10,0)                   DEFAULT NULL COMMENT '5日均线',
  `SHIBOR`                   	    VARCHAR(30)                     DEFAULT NULL COMMENT 'SHIBOR值',
  `SECURITYID`                      VARCHAR(100)                    DEFAULT NULL COMMENT '品种代码',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='SHIBOR移动均值';


CREATE TABLE IF NOT EXISTS `TIR_SERIES_BUYBACK` (
  `BENCHMARK_EFFECTIVE_DATE`        VARCHAR(30)                     DEFAULT NULL COMMENT '回购定盘利率生成日期',
  `MDTYPE`                          VARCHAR(30)                     DEFAULT NULL COMMENT 'K-回购定盘利率',
  `TERM_FLOOR_LIMIT`                VARCHAR(30)                     DEFAULT NULL COMMENT '定盘利率品种期限下限',
  `TERM_UPPER_LIMIT`                VARCHAR(30)                     DEFAULT NULL COMMENT '定盘利率品种期限上限',
  `BUY_BACK_IR`                     VARCHAR(30)                     DEFAULT NULL COMMENT '回购定盘利率',
  `SECURITYID`                      VARCHAR(100)                    DEFAULT NULL COMMENT '品种代码',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='回购定盘利率';



CREATE TABLE IF NOT EXISTS `TIR_SERIES_SHIBOR` (
  `BENCHMARK_EFFECTIVE_DATE`        VARCHAR(30)                     DEFAULT NULL COMMENT '日期',
  `MDTYPE`                          VARCHAR(30)                     DEFAULT NULL COMMENT '0-基准利率',
  `SHIBOR`                			VARCHAR(30)                     DEFAULT NULL COMMENT 'SHIBOR值',
  `CHANGE_CLEANPRICE`               VARCHAR(30)                     DEFAULT NULL COMMENT '涨跌幅',
  `SECURITYID`                      VARCHAR(100)                    DEFAULT NULL COMMENT '期限品种',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='货币市场基准利率';


CREATE TABLE IF NOT EXISTS `TIR_SERIES_BOND_DY_ASSESS` (
  `QID`        						DECIMAL(16,0)                   DEFAULT NULL COMMENT '序列号',
  `TRANSACTTIME`                    VARCHAR(30)                     DEFAULT NULL COMMENT '交易时间',
  `SECURITYTYPE`                	VARCHAR(30)                     DEFAULT NULL COMMENT '本币市场行情',
  `MDTYPE`              			VARCHAR(30)                     DEFAULT NULL COMMENT '国债',
  `MDSUBTYPE`                       DECIMAL(10)                 	DEFAULT NULL COMMENT '动态估值',
  `BEG_DATE`                        CHAR(10)                   		DEFAULT NULL COMMENT '开始日期',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券动态估值';


CREATE TABLE IF NOT EXISTS `TIR_SERIES_BOND_DY_ASSESS_EX` (
  `QID`        						DECIMAL(16,0)                   DEFAULT NULL COMMENT '序列号',
  `BEG_DATE`                    	CHAR(10)                  		DEFAULT NULL COMMENT '开始时间',
  `SECURITYID`                		VARCHAR(30)                     DEFAULT NULL COMMENT '债券代码',
  `SYMBOL`              			VARCHAR(30)                     DEFAULT NULL COMMENT '债券名称',
  `ASSESSFULLPRICE`                 VARCHAR(30)                   	DEFAULT NULL COMMENT '估值全价',
  `ASSESSNETPRICE`                  VARCHAR(30)                     DEFAULT NULL COMMENT '估值净价',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券动态估值扩展表';


CREATE TABLE IF NOT EXISTS `TIR_SERIES_BOND_CL_ASSESS` (
 `TRANSACTTIME`        				VARCHAR(30)                   	DEFAULT NULL COMMENT '交易时间',
  `SECURITYTYPE`                    VARCHAR(30)                  	DEFAULT NULL COMMENT '国债',
  `MDTYPE`                			VARCHAR(30)                     DEFAULT NULL COMMENT '本币市场行情',
  `MDSUBTYPE`              			DECIMAL(10)                  	DEFAULT NULL COMMENT '收盘估值',
  `SECURITYID`                 		VARCHAR(30)                   	DEFAULT NULL COMMENT '债券代码',
  `SYMBOL`                 			VARCHAR(30)                     DEFAULT NULL COMMENT '债券名称',
  `CURRENCY`                      	VARCHAR(30)                     DEFAULT NULL COMMENT '币种',
  `COUPONRATETYPE`                  DECIMAL(5)                     	DEFAULT NULL COMMENT '固定利率债',
  `ASSESSFULLPRICE`                 VARCHAR(30)                     DEFAULT NULL COMMENT '估值全价',
  `SPREADCNYDIRTYPRICE`             VARCHAR(30)                     DEFAULT NULL COMMENT '估值全价折人民币',
  `ASSESSNETPRICE`                  VARCHAR(30)                     DEFAULT NULL COMMENT '估值净价',
  `SPREADCNYPRICE`					VARCHAR(30)						DEFAULT NULL COMMENT '估值净价折人民币',
  `ASSESSYIELDRATE`                 VARCHAR(30)                     DEFAULT NULL COMMENT '收益率值',
  `MODIFYDURATION`                  VARCHAR(30)                     DEFAULT NULL COMMENT '估值修正期',
  `CONVEXITY`                       VARCHAR(30)                     DEFAULT NULL COMMENT '估值凸性',
  `SPREADPX`                        VARCHAR(30)                     DEFAULT NULL COMMENT '估值基点价值',
  `BEG_DATE`                      	CHAR(10)                     	DEFAULT NULL COMMENT '开始日期',
  `SPREADCONVEXITY`                 VARCHAR(30)                     DEFAULT NULL COMMENT '更新时间',
  `SPREADDURATION`                  VARCHAR(30)                     DEFAULT NULL COMMENT '估值利差久期',
  `DURATION`                      	VARCHAR(30)                     DEFAULT NULL COMMENT '估值利差凸性',
  `UPDATETIME`                      VARCHAR(30)                     DEFAULT NULL COMMENT '估值利率久期'
  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券收盘估值表';

  
  
  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_OR_SERIES` (
	`QID`            			DECIMAL(16)			DEFAULT NULL COMMENT '序号',
	`BEG_DATE`             		VARCHAR(20)		DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`              VARCHAR(30)        DEFAULT NULL COMMENT '日期',
	`MDTYPE`             		VARCHAR(30)        DEFAULT NULL COMMENT '本币市场行情',
	`MARKETINDICATOR`           VARCHAR(50)        DEFAULT NULL COMMENT '买断式回购',
	`MDSUBTYPE`             	VARCHAR(10)        DEFAULT NULL COMMENT '回购利率行情',
	`SECURITYID`             	VARCHAR(100)       DEFAULT NULL COMMENT '交易品种代码',
	`SYMBOL`             		VARCHAR(50)        DEFAULT NULL COMMENT '交易品种名称',
	`PRE_CLOSING_RATE`          VARCHAR(30)        DEFAULT NULL COMMENT '前收盘利率',
	`PRE_WET_AVG_RATE`          VARCHAR(30)        DEFAULT NULL COMMENT '前加权平均利率',
	`OPENING_RATE`              VARCHAR(30)        DEFAULT NULL COMMENT '开盘利率',
	`LATEST_RATE`               VARCHAR(30)        DEFAULT NULL COMMENT '最新利率',
	`HIGHEST_RATE`              VARCHAR(30)        DEFAULT NULL COMMENT '最高利率',
	`LOWEST_RATE`               VARCHAR(30)        DEFAULT NULL COMMENT '最低利率',
	`CLOSING_RATE`              VARCHAR(30)        DEFAULT NULL COMMENT '收盘利率',
	`WET_AVG_RATE`              VARCHAR(30)        DEFAULT NULL COMMENT '加权平均利率',
	`TURNOVER`             		VARCHAR(30)        DEFAULT NULL COMMENT '成交量',
	`UPDATETIME`             	VARCHAR(30)		DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='买断式回购利率行情';

	-- TTRD_CMDS_EXECUTIONREPORT增加字段TEXT
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'TEXT';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT ADD TEXT VARCHAR(100);
    END IF;



	-- TTRD_CMDS_EXECUTIONREPORT增加字段LEGSIDE
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'LEGSIDE';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT ADD LEGSIDE VARCHAR(5);
    END IF;
	
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中LEAVES_TOTAL_QTY字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'LEAVES_TOTAL_QTY';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY LEAVES_TOTAL_QTY VARCHAR(20);
    END IF;
	
	

	  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE` (
	`QID`                DECIMAL(16)DEFAULT NULL COMMENT '序号',
	`BEG_DATE`           VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`       VARCHAR(21)   DEFAULT NULL COMMENT '交易时间',
	`MDTYPE`             VARCHAR(30)   DEFAULT NULL COMMENT '本币市场行情',
	`MDSUBTYPE`          DECIMAL(10)   DEFAULT NULL COMMENT '基准券实时收益率曲线数据',
	`SECURITYTYPE`       VARCHAR(30)   DEFAULT NULL COMMENT '国债',
	`SECURITYID`         VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`             VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`YIELD_TERM`         VARCHAR(50)   DEFAULT NULL COMMENT '期限',
	`SEC_TERM_YEARLY`    VARCHAR(30)   DEFAULT NULL COMMENT '年化债券期限',
	`CONPREHENSIVE_RATE` VARCHAR(30)   DEFAULT NULL COMMENT '综合收益率',
	`UPDATETIME`         VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='基准曲线行情';



  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXOPT_DELTA` (
	`QID`                  DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BEG_DATE`             VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`         VARCHAR(21)   DEFAULT NULL COMMENT '交易时间',
	`MDTYPE`               VARCHAR(30)   DEFAULT NULL COMMENT '本币市场行情',
	`MDSUBTYPE`            DECIMAL(10)   DEFAULT NULL COMMENT '基准券实时收益率曲线数据',
	`SECURITYID`           VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`               VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`YIELD_TERM`           VARCHAR(50)   DEFAULT NULL COMMENT '期限',
	`SETTL_DATE`           VARCHAR(30)   DEFAULT NULL COMMENT '到期日',
	`CALCULATE_DAYS`       VARCHAR(30)   DEFAULT NULL COMMENT '计算天数',
	`EXECUTE_PRICE`        VARCHAR(30)   DEFAULT NULL COMMENT '执行价格',
	`CALL_DELTA`           VARCHAR(30)   DEFAULT NULL COMMENT '看涨期权',
	`PUT_DELTA`            VARCHAR(30)   DEFAULT NULL COMMENT '看跌期权',
	`DERIVATIVE_EXE_STYLE`  VARCHAR(30)   DEFAULT NULL COMMENT '0-欧式期权',
	`VOLATILITY`           VARCHAR(30)   DEFAULT NULL COMMENT '隐含波动率',
	`DERIVATIVE_OPT_ATTR`  VARCHAR(30)   DEFAULT NULL COMMENT '0-ATM',
	`UPDATETIME`           VARCHAR(30)		DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇期权DELTA';



  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXOPT_DELTA_EX` (
	`QID`                      VARCHAR(30)   DEFAULT NULL COMMENT '序号',
	`BENCHMARK_PRICE`          VARCHAR(30)   DEFAULT NULL COMMENT '参考利率值',
	`BENCHMARK_CURVE_CURRENCY` VARCHAR(30)   DEFAULT NULL COMMENT '参考利率的货币品种',
	`BENCHMARK_CURVE_NAME`     VARCHAR(30)   DEFAULT NULL COMMENT '参考利率名称',
	`UPDATETIME`               VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇期权DELTA扩展表';



  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXOPT_VOL` (
	`QID`                 DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BEG_DATE`            VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`        VARCHAR(21)   DEFAULT NULL COMMENT '交易时间',
	`CALCULATETIME`       VARCHAR(30)   DEFAULT NULL COMMENT '计算时间',
	`MDTYPE`              VARCHAR(30)   DEFAULT NULL COMMENT '外汇期权数据',
	`MDSUBTYPE`           DECIMAL(10)   DEFAULT NULL COMMENT '外汇期权波动率',
	`SECURITYID`          VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`              VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`DERIVATIVE_OPT_ATTR`  VARCHAR(50)   DEFAULT NULL COMMENT '波动率类型',
	`REFERENCE_SYMBOL`    VARCHAR(30)   DEFAULT NULL COMMENT '货币对',
	`YIELD_TERM`          VARCHAR(30)   DEFAULT NULL COMMENT '标准期限',
	`VOLATILITY`          VARCHAR(30)   DEFAULT NULL COMMENT '波动率',
	`UPDATETIME`          VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇期权隐含波动率曲线';




  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXSWAP` (
	`QID`              DECIMAL(16)	DEFAULT NULL COMMENT '序号',
	`BEG_DATE`         VARCHAR(10)	DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`     VARCHAR(21)	DEFAULT NULL COMMENT '交易时间',
	`MDTYPE`           VARCHAR(30)	DEFAULT NULL COMMENT '9 缺省值',
	`MDSUBTYPE`        DECIMAL(10)	DEFAULT NULL COMMENT '16 缺省值',
	`SECURITYID`       VARCHAR(100)	DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`           VARCHAR(50)	DEFAULT NULL COMMENT '曲线名称',
	`REFERENCE_SYMBOL` VARCHAR(50)	DEFAULT NULL COMMENT '货币对',
	`UPDATETIME`       VARCHAR(30)  DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇掉期曲线';




  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXSWAP_EX` (
	`QID`        DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`YIELD_TERM` VARCHAR(21)   DEFAULT NULL COMMENT '期限',
	`SETTL_DATE` VARCHAR(30)   DEFAULT NULL COMMENT '远端起息日',
	`CURVE_TYPE` VARCHAR(20)   DEFAULT NULL COMMENT '类型--掉期点，最优报买价，最优报卖价',
	`YIELD_PX`   VARCHAR(100)   DEFAULT NULL COMMENT '类型对应的掉期点值，最优报买价，最优报卖价',
	`SPREAD`     VARCHAR(50)	DEFAULT NULL COMMENT '类型对应的掉期全价汇率，最优报买全价汇率，最优报卖全价汇率'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇掉期曲线扩展表';




  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FX_IMPRATE` (
	`QID`              DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BEG_DATE`         VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`     VARCHAR(21)   DEFAULT NULL COMMENT '交易时间',
	`MDTYPE`           VARCHAR(30)   DEFAULT NULL COMMENT '9 缺省值',
	`MDSUBTYPE`        DECIMAL(10)   DEFAULT NULL COMMENT '16 缺省值',
	`SECURITYID`       VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`           VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`REFERENCE_SYMBOL` VARCHAR(50)   DEFAULT NULL COMMENT '货币对',
	`UPDATETIME`       VARCHAR(30)	 DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外币隐含利率';
	
	
	
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FX_IMPRATE_EX` (
	`QID`              DECIMAL(16) 	DEFAULT NULL COMMENT '序号',
	`YIELD_TERM`       VARCHAR(30)   DEFAULT NULL COMMENT '曲线期限',
	`FC_IMPLIED_RATE1` VARCHAR(30)   DEFAULT NULL COMMENT '外币隐含利率，一年以下单利，一年以上复利',
	`FC_IMPLIED_RATE2` VARCHAR(30)   DEFAULT NULL COMMENT '外币隐含利率，连续复利',
	`RMB_RATE1`        VARCHAR(30)   DEFAULT NULL COMMENT '人民币端利率(原始)',
	`RMB_RATE2`        VARCHAR(30)   DEFAULT NULL COMMENT '人民币端利率(连续复利)',
	`RMB_DATA_SOURCE`  VARCHAR(30)   DEFAULT NULL COMMENT '人民币端利率来源',
	`SWAP_DATA_SOURCE` VARCHAR(30)   DEFAULT NULL COMMENT '掉期点来源',
	`SWAP_PX`          VARCHAR(30)   DEFAULT NULL COMMENT '掉期点值',
	`SPOT_DATA_SOURCE` VARCHAR(30)   DEFAULT NULL COMMENT '即期价格来源',
	`SPOT_PX`          VARCHAR(30)	  DEFAULT NULL COMMENT '即期价格'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外币隐含利率扩展表';


  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXCSWAP` (
	`QID`          DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BEG_DATE`     VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME` VARCHAR(21)   DEFAULT NULL COMMENT '交易时间',
	`MDTYPE`       VARCHAR(30)   DEFAULT NULL COMMENT '9 缺省值',
	`MDSUBTYPE`    DECIMAL(10)   DEFAULT NULL COMMENT '16 缺省值',
	`SECURITYID`   VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`       VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`UPDATETIME`   VARCHAR(30)	 DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇掉期C-SWAP';



  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_FXCSWAP_EX` (
	`QID`        DECIMAL(16)		DEFAULT NULL COMMENT '序号',
	`YIELD_TERM` VARCHAR(30)   DEFAULT NULL COMMENT '期限',
	`CURVE_TYPE` VARCHAR(30)   DEFAULT NULL COMMENT '掉期点来源',
	`SWAP_POINT` VARCHAR(30)   DEFAULT NULL COMMENT '掉期点',
	`SWAP_RATE`  VARCHAR(30)	DEFAULT NULL COMMENT '外汇掉期全价汇率'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='外汇掉期C-SWAP扩展表';


  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CURVE_IRS` (
	`QID`           DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BEG_DATE`      VARCHAR(10)   DEFAULT NULL COMMENT '开始时间',
	`CALCULATETIME` VARCHAR(30)   DEFAULT NULL COMMENT '计算时间',
	`MDTYPE`        VARCHAR(30)   DEFAULT NULL COMMENT '9 缺省值',
	`MDSUBTYPE`     DECIMAL(10)   DEFAULT NULL COMMENT '16 缺省值',
	`SECURITYID`    VARCHAR(100)   DEFAULT NULL COMMENT '曲线代码',
	`SYMBOL`        VARCHAR(50)   DEFAULT NULL COMMENT '曲线名称',
	`YIELD_TERM`    VARCHAR(30)   DEFAULT NULL COMMENT '曲线期限',
	`YIELD_PX`      VARCHAR(30)   DEFAULT NULL COMMENT '收益率',
	`UPDATETIME`    VARCHAR(30)	  DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='利率互换曲线';


  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_INDEX_POINT` (
	`QID`                    DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BENCHMARKEFFECTIVEDATE` VARCHAR(30)   DEFAULT NULL COMMENT '开始时间',
	`MDTYPE`                 VARCHAR(30)   DEFAULT NULL COMMENT 'E-可交易债券指数',
	`MDSUBTYPE`              DECIMAL(10)   DEFAULT NULL COMMENT '56-可交易债券指数点位',
	`INDEXID`                VARCHAR(30)   DEFAULT NULL COMMENT '指数代码',
	`SECURITYID`             VARCHAR(30)   DEFAULT NULL COMMENT '固定传-',
	`INDEXPOINT`             DECIMAL(13,4)   DEFAULT NULL COMMENT '指数点位',
	`MODIFYDURATION`         VARCHAR(30)   DEFAULT NULL COMMENT '平均修正久期',
	`CONVEXITY`              VARCHAR(30)   DEFAULT NULL COMMENT '指数平均凸性',
	`SPREADPX`               VARCHAR(30)   DEFAULT NULL COMMENT '指数平均基点价值',
	`REINVESTMENTVALUE`      VARCHAR(30)   DEFAULT NULL COMMENT '再投资利率',
	`REINVESTMENTANNUALTIME` VARCHAR(30)   DEFAULT NULL COMMENT '再投资利率年化时间',
	`UPDATETIME`             VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='可交易债券指数点位';



  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_INDEX_IGD` (
	`QID`                    DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BENCHMARKEFFECTIVEDATE` VARCHAR(30)   DEFAULT NULL COMMENT '日期',
	`DATASOURCESTRING`       VARCHAR(30)   DEFAULT NULL COMMENT '数据来源',
	`WEIGHTEDVALUE`          VARCHAR(20)   DEFAULT NULL COMMENT '权重',
	`MDTYPE`                 VARCHAR(30)   DEFAULT NULL COMMENT '可交易债券指数',
	`MDSUBTYPE`              VARCHAR(30)   DEFAULT NULL COMMENT '可交易债券指数成分',
	`INDEXID`                VARCHAR(30)   DEFAULT NULL COMMENT '指数代码',
	`SECURITYID`             VARCHAR(30)   DEFAULT NULL COMMENT '债券代码',
	`VALUEATION`             VARCHAR(30)   DEFAULT NULL COMMENT '估值',
	`TRANSACTIONPRICE`       VARCHAR(30)   DEFAULT NULL COMMENT '成交价',
	`MIDDLEOFBESTPRICE`      VARCHAR(30)   DEFAULT NULL COMMENT '最优报价中间价',
	`FINALVALUEPRICE`        VARCHAR(30)   DEFAULT NULL COMMENT '最终取值净价',
	`FINALVALUEDIRTYPRICE`   VARCHAR(30)   DEFAULT NULL COMMENT '最终取值全价',
	`UPDATETIME`            VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券指数成分';




  CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_INDEX_IGD_OPT` (
	`QID`                    DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BENCHMARKEFFECTIVEDATE` VARCHAR(30)   DEFAULT NULL COMMENT '日期',
	`SECURITYDEFINITIONTYPE` DECIMAL(10)   DEFAULT NULL COMMENT '可交易债券指数成分发行人可选',
	`INDEXID`                VARCHAR(30)   DEFAULT NULL COMMENT '指数代码',
	`PARTYID`                VARCHAR(30)   DEFAULT NULL COMMENT '机构代码',
	`PARTYROLE`              DECIMAL(10)   DEFAULT NULL COMMENT '发行人',
	`PARTYSUBID`             VARCHAR(30)   DEFAULT NULL COMMENT '机构全称',
	`PARTYSUBIDTYPE`         DECIMAL(10)   DEFAULT NULL COMMENT '124-机构全称',
	`UPDATETIME`             VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券指数成分发行人可选清单';
	
	
	-- 修改TTRD_CMDS_BOND_INDEX_IGD表中WEIGHTEDVALUE字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BOND_INDEX_IGD'
    AND COLUMN_NAME = 'WEIGHTEDVALUE';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_BOND_INDEX_IGD MODIFY WEIGHTEDVALUE VARCHAR(50);
    END IF;
	
	
	-- 修改TIR_SERIES_BOND_CL_ASSESS表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TIR_SERIES_BOND_CL_ASSESS'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TIR_SERIES_BOND_CL_ASSESS MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	-- 修改TIR_SERIES_BOND_DY_ASSESS_EX表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TIR_SERIES_BOND_DY_ASSESS_EX'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TIR_SERIES_BOND_DY_ASSESS_EX MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	
	-- 修改TIR_SERIES_BOND_DY_ASSESS_EX表中SECURITYID字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TIR_SERIES_BOND_DY_ASSESS_EX'
    AND COLUMN_NAME = 'SECURITYID';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TIR_SERIES_BOND_DY_ASSESS_EX MODIFY SECURITYID VARCHAR(100);
    END IF;
	
	
	
	-- 修改TTRD_CMDS_CURVE_FX_IMPRATE表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FX_IMPRATE'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FX_IMPRATE MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	
	-- 修改TTRD_CMDS_CURVE_IRS表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_IRS'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_IRS MODIFY SYMBOL VARCHAR(200);
    END IF;

  
  	-- 修改TTRD_CMDS_CURVE_FXOPT_DELTA表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXOPT_DELTA'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXOPT_DELTA MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	-- 修改TTRD_CMDS_CURVE_FXOPT_VOL表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXOPT_VOL'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXOPT_VOL MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	
	-- 修改TTRD_CMDS_CURVE_FXSWAP表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXSWAP'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXSWAP MODIFY SYMBOL VARCHAR(200);
    END IF;
  
  
  	-- 修改TTRD_CMDS_CURVE_FXCSWAP表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXCSWAP'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXCSWAP MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	-- 修改TTRD_CMDS_CURVE_FXOPT_DELTA_EX表中BENCHMARK_CURVE_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXOPT_DELTA_EX'
    AND COLUMN_NAME = 'BENCHMARK_CURVE_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXOPT_DELTA_EX MODIFY BENCHMARK_CURVE_NAME VARCHAR(150);
    END IF;
  
  
  -- 修改TTRD_CMDS_BOND_INDEX_IGD_OPT表中PARTYSUBID字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BOND_INDEX_IGD_OPT'
    AND COLUMN_NAME = 'PARTYSUBID';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_BOND_INDEX_IGD_OPT MODIFY PARTYSUBID VARCHAR(200);
    END IF;
	
	
	--  创建表TIR_SERIES_7DAYS_MOVE_AVG_RATE
	  CREATE TABLE IF NOT EXISTS `TIR_SERIES_7DAYS_MOVE_AVG_RATE` (
	`QID`                    DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BENCHMARKEFFECTIVEDATE` VARCHAR(30)   DEFAULT NULL COMMENT '生效日期',
	`MDTYPE` 				 VARCHAR(30)   DEFAULT NULL COMMENT '数据类型',
	`SECURITYID`             VARCHAR(30)   DEFAULT NULL COMMENT '品种代码',
	`CALCMETHOD`             VARCHAR(30)   DEFAULT NULL COMMENT '指数加权',
	`BUYBACKRATE`            VARCHAR(30)   DEFAULT NULL COMMENT '七天回购移动平均利率值',
	`UPDOWN`             	 VARCHAR(30)   DEFAULT NULL COMMENT '涨跌幅',
	`UPDATETIME`             VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='七天回购移动平均利率';
	
	
	-- 修改TTRD_CMDS_CURVE_IRS表中YIELD_PX字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_IRS'
    AND COLUMN_NAME = 'YIELD_PX';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_IRS MODIFY YIELD_PX VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_CURVE表中SEC_TERM_YEARLY字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE'
    AND COLUMN_NAME = 'SEC_TERM_YEARLY';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE MODIFY SEC_TERM_YEARLY VARCHAR(50);
    END IF;
	
	-- 修改TTRD_CMDS_CURVE表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE MODIFY SYMBOL VARCHAR(200);
    END IF;
	
	-- 修改TTRD_CMDS_EXECUTIONREPORT表中I_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'I_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT MODIFY I_NAME VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_EXECUTIONREPORT表中U_I_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'U_I_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT MODIFY U_I_NAME VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_MAKEMARKET表中I_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'I_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET MODIFY I_NAME VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_MAKEMARKET表中TRADER字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'TRADER';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET MODIFY TRADER VARCHAR(100);
    END IF;
  
	 -- 修改TTRD_CMDS_QUOTE_MAKEMARKET表中INITIATOR_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'INITIATOR_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET MODIFY INITIATOR_NAME VARCHAR(200);
    END IF;
	
	-- 修改TTRD_CMDS_ABS_SERIES表中I_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_ABS_SERIES'
    AND COLUMN_NAME = 'I_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_ABS_SERIES MODIFY I_NAME VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_IBLB_SERIES表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_IBLB_SERIES'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_IBLB_SERIES MODIFY SYMBOL VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_IBLB_SERIES_INST表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_IBLB_SERIES_INST'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_IBLB_SERIES_INST MODIFY SYMBOL VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_IBLB_SERIES_INST表中PARTYID字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_IBLB_SERIES_INST'
    AND COLUMN_NAME = 'PARTYID';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_IBLB_SERIES_INST MODIFY PARTYID VARCHAR(150);
    END IF;
	
	-- 修改TTRD_CMDS_CR_SERIES表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CR_SERIES'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CR_SERIES MODIFY SYMBOL VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_CR_SERIES_INST表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CR_SERIES_INST'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CR_SERIES_INST MODIFY SYMBOL VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_CR_SERIES_INST表中PARTYID字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CR_SERIES_INST'
    AND COLUMN_NAME = 'PARTYID';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CR_SERIES_INST MODIFY PARTYID VARCHAR(150);
    END IF;
	 
	 -- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中I_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'I_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY I_NAME VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中INITIATOR字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'INITIATOR';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY INITIATOR VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中TRADER字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'TRADER';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY TRADER VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中INITIATOR_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'INITIATOR_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY INITIATOR_NAME VARCHAR(300);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中PARTYID字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'PARTYID';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY PARTYID VARCHAR(150);
    END IF;
	
	-- 修改TTRD_CMDS_QUOTE_CLICKDEAL表中SHORT_LEGAL_CHINESE_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_CLICKDEAL'
    AND COLUMN_NAME = 'SHORT_LEGAL_CHINESE_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_QUOTE_CLICKDEAL MODIFY SHORT_LEGAL_CHINESE_NAME VARCHAR(150);
    END IF;
	
	-- 修改TTRD_CMDS_OR_SERIES表中SYMBOL字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_OR_SERIES'
    AND COLUMN_NAME = 'SYMBOL';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_OR_SERIES MODIFY SYMBOL VARCHAR(100);
    END IF;
	
	-- 修改TTRD_CMDS_CURVE_FXOPT_DELTA_EX表中BENCHMARK_CURVE_NAME字段长度
   SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_CURVE_FXOPT_DELTA_EX'
    AND COLUMN_NAME = 'BENCHMARK_CURVE_NAME';
	IF ROWCOUNT > 0 THEN    -- 如果有记录
        ALTER TABLE TTRD_CMDS_CURVE_FXOPT_DELTA_EX MODIFY BENCHMARK_CURVE_NAME VARCHAR(300);
    END IF;
	
	-- TTRD_CMDS_EXECUTIONREPORT增加字段PRE_MARKETBOND_INDICATOR
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'PRE_MARKETBOND_INDICATOR';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT ADD PRE_MARKETBOND_INDICATOR CHAR(1) DEFAULT NULL COMMENT '上市前债券';
    END IF;
	
	-- TTRD_CMDS_EXECUTIONREPORT增加字段TRADE_METHOD
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'TRADE_METHOD';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT ADD TRADE_METHOD DECIMAL(10) DEFAULT NULL COMMENT '交易方式';
    END IF;
	
	-- TTRD_CMDS_EXECUTIONREPORT增加字段TRANSACTION_METHOD
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT'
    AND COLUMN_NAME = 'TRANSACTION_METHOD';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_EXECUTIONREPORT ADD TRANSACTION_METHOD VARCHAR(10)  DEFAULT NULL COMMENT '成交方向';
    END IF;
	
	
	-- TTRD_CMDS_BONDSERIES增加字段TRANSACTION_NUM
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BONDSERIES'
    AND COLUMN_NAME = 'TRANSACTION_NUM';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_BONDSERIES ADD TRANSACTION_NUM DECIMAL(10)  DEFAULT NULL COMMENT '成交笔数';
    END IF;
	
	
	-- TTRD_CMDS_BONDSERIES增加字段NET_PRICE_VOL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BONDSERIES'
    AND COLUMN_NAME = 'NET_PRICE_VOL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_BONDSERIES ADD NET_PRICE_VOL DECIMAL(25,6)  DEFAULT NULL COMMENT '净价涨跌';
    END IF;
	
	-- TTRD_CMDS_BONDSERIES增加字段YIELD_VOL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BONDSERIES'
    AND COLUMN_NAME = 'YIELD_VOL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_BONDSERIES ADD YIELD_VOL DECIMAL(25,6)  DEFAULT NULL COMMENT '收益率涨跌';
    END IF;
	
	-- TTRD_CMDS_BONDSERIES增加字段TERM_TO_MATURITY
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_BONDSERIES'
    AND COLUMN_NAME = 'TERM_TO_MATURITY';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_BONDSERIES ADD TERM_TO_MATURITY VARCHAR(30)  DEFAULT NULL COMMENT '年化待偿期';
    END IF;
	
	
	-- TTRD_CMDS_QUOTE_MAKEMARKET增加字段B_PRINCIPAL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'B_PRINCIPAL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET ADD B_PRINCIPAL DECIMAL(25,6)  DEFAULT NULL COMMENT '每百元本金额--买';
    END IF;
	
	
	-- TTRD_CMDS_QUOTE_MAKEMARKET增加字段B_PRINCIPAL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'B_TOTAL_PRINCIPAL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET ADD B_TOTAL_PRINCIPAL DECIMAL(25,6)  DEFAULT NULL COMMENT '当前本金额--买';
    END IF;
	
	-- TTRD_CMDS_QUOTE_MAKEMARKET增加字段S_PRINCIPAL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'S_PRINCIPAL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET ADD S_PRINCIPAL DECIMAL(25,6)  DEFAULT NULL COMMENT '每百元本金额--卖';
    END IF;
	
	
	-- TTRD_CMDS_QUOTE_MAKEMARKET增加字段S_TOTAL_PRINCIPAL
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TTRD_CMDS_QUOTE_MAKEMARKET'
    AND COLUMN_NAME = 'S_TOTAL_PRINCIPAL';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TTRD_CMDS_QUOTE_MAKEMARKET ADD S_TOTAL_PRINCIPAL DECIMAL(25,6)  DEFAULT NULL COMMENT '当前本金额--卖';
    END IF;
	
	
	--  创建表TTRD_CMDS_RMB_RATE_INDEX
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_RMB_RATE_INDEX` (
	`QID`                    	DECIMAL(16)   DEFAULT NULL COMMENT '序号',
	`BENCHMARK_EFFECTIVE_DATE`  CHAR(8)   DEFAULT NULL COMMENT '指数日期',
	`MDTYPE` 				 	CHAR(1)   DEFAULT NULL COMMENT '行情类型',
	`SECURITY_ID`             	VARCHAR(50)   DEFAULT NULL COMMENT '交易品种代码',
	`RMB_RATE_INDEX`            DECIMAL(25,8)   DEFAULT NULL COMMENT '人民币汇率指数',
	`INDEX_VOL`            		DECIMAL(25,8)  DEFAULT NULL COMMENT '指数涨跌',
	`UPDATE_TIME`             	VARCHAR(30)	DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='人民币汇率指数';
	
	
	
	--  创建表TTRD_CMDS_BOND_BEST_PRICE
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_BEST_PRICE` (
	`QID`                    			DECIMAL(16)   	DEFAULT NULL COMMENT '序列',
	`TRANSACT_TIME`  					VARCHAR(30)   	DEFAULT NULL COMMENT '行情日期',
	`BEG_DATE` 				 			CHAR(10)   	  	DEFAULT NULL COMMENT '开始日期',
	`PRE_MARKET_BOND_INDICATOR`         CHAR(1)   	  	DEFAULT NULL COMMENT '上市前债券',
	`MDTYPE`            				CHAR(1)   	  	DEFAULT NULL COMMENT '行情类型',
	`MDSUBTYPE`            				INT  		  	DEFAULT NULL COMMENT '最优报价行情',
	`MARKET_INDICATOR`            		CHAR(1)  	  	DEFAULT NULL COMMENT '市场标识-现券买卖',
	`TRADE_METHOD`            			INT  		  	DEFAULT NULL COMMENT '交易方式-匿名点击',
	`SECURITY_ID`            			VARCHAR(50)   	DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`            				VARCHAR(50)   	DEFAULT NULL COMMENT '债券名称',
	`DIRECTION`            				CHAR(1)  	  	DEFAULT NULL COMMENT '方向',
	`SETTLE_TYPE`            			CHAR(1)  	  	DEFAULT NULL COMMENT '清算速度',
	`BEST_NET_PRICE`            		DECIMAL(25,5)  	DEFAULT NULL COMMENT '最优净价',
	`TRADE_VOLUME`            			INT			  	DEFAULT NULL COMMENT '最优报价量',
	`NUM_OF_ORDERS`            			INT 	  		DEFAULT NULL COMMENT '最优订单笔数',
	`BEST_FULL_PRICE`            		DECIMAL(25,5)  	DEFAULT NULL COMMENT '最优全价',
	`BEST_YTM`            				DECIMAL(25,5)  	DEFAULT NULL COMMENT '最优到期收益率',
	`UPDATE_TIME`             			VARCHAR(30)		DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券买卖最优报价行情';
	
	
	
	
	--  创建表TTRD_CMDS_BOND_CLEAN
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_CLEAN` (
	`QID`                    			DECIMAL(16)   		DEFAULT NULL COMMENT '序列',
	`BEG_DATE`  						CHAR(10)   			DEFAULT NULL COMMENT '开始日期',
	`MDTYPE` 				 			CHAR(1)   	  		DEFAULT NULL COMMENT '市场行情-R',
	`MARKET_INDICATOR`         			CHAR(1)   	  		DEFAULT NULL COMMENT '市场行情子类型-清洗后数据',
	`MDSUBTYPE`            				INT   	  			DEFAULT NULL COMMENT '市场标识',
	`TRADE_METHOD`            			INT  		  		DEFAULT NULL COMMENT '交易方式-汇总行情',
	`SECURITY_ID`            			VARCHAR(50)  	  	DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`            				VARCHAR(50)  		DEFAULT NULL COMMENT '债券名称',
	`TERM_TO_MATURITY`            		DECIMAL(30,10)   	DEFAULT NULL COMMENT '待偿期',
	`NET_PRICE`            				DECIMAL(25,5)   	DEFAULT NULL COMMENT '最新净价',
	`YIELD`            					DECIMAL(25,5)  	  	DEFAULT NULL COMMENT '最新收益率',
	`VOLATILITY`            			DECIMAL(25,5)  	  	DEFAULT NULL COMMENT '涨跌幅',
	`YIELD_VOL`            				DECIMAL(25,5)  		DEFAULT NULL COMMENT '收益率涨跌',
	`TRANS_VOLUME`            			DECIMAL(25,5)		DEFAULT NULL COMMENT '成交量',
	`TRANS_NUM`            				INT 	  			DEFAULT NULL COMMENT '成交笔数',
	`WET_AVG_NET_PRICE`            		DECIMAL(25,5)  		DEFAULT NULL COMMENT '加权平均净价',
	`WET_AVG_YIELD`            			DECIMAL(25,5)  		DEFAULT NULL COMMENT '加权平均收益率',
	`OPEN_NET_PRICE`             		DECIMAL(25,5)		DEFAULT NULL COMMENT '开盘净价',
	`HIGH_NET_PRICE`            		DECIMAL(25,5)   	DEFAULT NULL COMMENT '最高净价',
	`LOW_NET_PRICE`            			DECIMAL(25,5)   	DEFAULT NULL COMMENT '最低净价',
	`OPEN_YIELD`            			DECIMAL(25,5)  	  	DEFAULT NULL COMMENT '开盘收益率',
	`HIGH_YIELD`            			DECIMAL(25,5)  	  	DEFAULT NULL COMMENT '最高收益率',
	`LOW_YIELD`            				DECIMAL(25,5)  		DEFAULT NULL COMMENT '最低收益率',
	`PRE_CLOSE_YIELD`            		DECIMAL(25,5)		DEFAULT NULL COMMENT '前收盘收益率',
	`PRE_CLOSE_NET_PRICE`            	DECIMAL(25,5) 	  	DEFAULT NULL COMMENT '前收盘净价',
	`PRE_WET_AVG_NET_PRICE`            	DECIMAL(25,5)  		DEFAULT NULL COMMENT '前加权平均净价',
	`PRE_WET_AVG_YIELD`            		DECIMAL(25,5)  		DEFAULT NULL COMMENT '前加权平均收益率',
	`UPDATE_TIME`             			VARCHAR(30)			DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券清洗后盘中/收盘行情';
	
	
	--  创建表TTRD_CMDS_BOND_DEPTH
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_DEPTH` (
	`QID`                    			DECIMAL(16)   		DEFAULT NULL COMMENT '序列',
	`TRANSACT_TIME`  					VARCHAR(30)  		DEFAULT NULL COMMENT '行情日期',
	`BEG_DATE` 				 			CHAR(10)   	  		DEFAULT NULL COMMENT '开始日期',
	`PRE_MARKET_BOND_INDICATOR`         CHAR(1)   	  		DEFAULT NULL COMMENT '上市前债券',
	`MDTYPE`            				CHAR(1)   	  		DEFAULT NULL COMMENT '市场行情',
	`MARKET_INDICATOR`            		CHAR(1)  		  	DEFAULT NULL COMMENT '市场行情子类型',
	`MDSUBTYPE`            				INT  	  			DEFAULT NULL COMMENT '市场标识',
	`TRADE_METHOD`            			INT  				DEFAULT NULL COMMENT '交易方式',
	`SECURITY_ID`            			VARCHAR(50)   		DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`            				VARCHAR(50)   		DEFAULT NULL COMMENT '债券名称',
	`MD_BOOK_TYPE`            			INT 	  			DEFAULT NULL COMMENT '行情类型-档位行情',
	`MARKET_DEPTH`            			INT  	  			DEFAULT NULL COMMENT '档位',
	
	`SETTLE_TYPE1`            			CHAR(1)				DEFAULT NULL COMMENT '清算速度1',
	`NET_PRICE1`            			DECIMAL(30,8) 	  	DEFAULT NULL COMMENT '净价1',
	`TRADE_VOLUME1`            			INT  				DEFAULT NULL COMMENT '报价量1',
	`FULL_PRICE1`            			DECIMAL(30,8)  		DEFAULT NULL COMMENT '全价1',
	`YTM1`             					DECIMAL(30,8)		DEFAULT NULL COMMENT '到期收益率1',
	`DIRECTION1`            				CHAR(1)  		DEFAULT NULL COMMENT '报价方向1',
	                                                                              
	`SETTLE_TYPE2`            			CHAR(1)				DEFAULT NULL COMMENT '清算速度2',
	`NET_PRICE2`            			DECIMAL(30,8)  	  	DEFAULT NULL COMMENT '净价2',
	`TRADE_VOLUME2`            			INT  		  	  	DEFAULT NULL COMMENT '报价量2',
	`FULL_PRICE2`            			DECIMAL(30,8)  		DEFAULT NULL COMMENT '全价2',
	`YTM2`            					DECIMAL(30,8)		DEFAULT NULL COMMENT '到期收益率2',
	`DIRECTION2`            				CHAR(1)  		DEFAULT NULL COMMENT '报价方向2',
	                                                                              
	`SETTLE_TYPE3`            			CHAR(1)				DEFAULT NULL COMMENT '清算速度3',
	`NET_PRICE3`            			DECIMAL(30,8)		DEFAULT NULL COMMENT '净价3',
	`TRADE_VOLUME3`             		INT  				DEFAULT NULL COMMENT '报价量3',
	`FULL_PRICE3`            			DECIMAL(30,8)		DEFAULT NULL COMMENT '全价3',
	`YTM3`            					DECIMAL(30,8)		DEFAULT NULL COMMENT '到期收益率3',
	`DIRECTION3`            				CHAR(1)  		DEFAULT NULL COMMENT '报价方向3',
	                                                                              
	`SETTLE_TYPE4`            			CHAR(1)		  		DEFAULT NULL COMMENT '清算速度4',
	`NET_PRICE4`             			DECIMAL(30,8)		DEFAULT NULL COMMENT '净价4',
	`TRADE_VOLUME4`            			INT  		   		DEFAULT NULL COMMENT '报价量4',
	`FULL_PRICE4`            			DECIMAL(30,8)   	DEFAULT NULL COMMENT '全价4',
	`YTM4`            					DECIMAL(30,8)  	  	DEFAULT NULL COMMENT '到期收益率4',
	`DIRECTION4`            				CHAR(1)  		DEFAULT NULL COMMENT '报价方向4',
	                                                                              
	`SETTLE_TYPE5`            			CHAR(1)		  		DEFAULT NULL COMMENT '清算速度5',
	`NET_PRICE5`            			DECIMAL(30,8)		DEFAULT NULL COMMENT '净价5',
	`TRADE_VOLUME5`            			INT  		 	  	DEFAULT NULL COMMENT '报价量5',
	`FULL_PRICE5`            			DECIMAL(30,8)  		DEFAULT NULL COMMENT '全价5',
	`YTM5`            					DECIMAL(30,8)  		DEFAULT NULL COMMENT '到期收益率5',
	`DIRECTION5`            				CHAR(1)  		DEFAULT NULL COMMENT '报价方向5',
	`UPDATE_TIME`             			VARCHAR(30)			DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券买卖-档位行情（BOND)';
	

	
	--  创建表TTRD_CMDS_BOND_FORWARD
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_FORWARD` (
	`QID`                    					DECIMAL(16)   				DEFAULT NULL COMMENT '序列',
	`TRANSACT_TIME`  							VARCHAR(30)  				DEFAULT NULL COMMENT '行情日期',
	`BEG_DATE` 				 					CHAR(10)   	  				DEFAULT NULL COMMENT '开始日期',
	`MDTYPE`         							CHAR(1)   	  				DEFAULT NULL COMMENT '市场行情-R',
	`MARKET_INDICATOR`            				CHAR(1)   	  				DEFAULT NULL COMMENT '市场行情子类型',
	`MDSUBTYPE`            						INT  		  				DEFAULT NULL COMMENT '市场标识',
	`SECURITY_ID`            					VARCHAR(50)  	  			DEFAULT NULL COMMENT '交易品种代码',
	`SYMBOL`            						VARCHAR(50)  				DEFAULT NULL COMMENT '交易品种名称',
	`PRE_CLS_F_NET_PRICE`            			DECIMAL(30,10)   			DEFAULT NULL COMMENT '前收盘远期净价',
	`PRE_WET_F_NET_PRICE`            			DECIMAL(30,10)   			DEFAULT NULL COMMENT '前加权平均远期净价',
	`VOLATILITY`            					DECIMAL(30,10) 	  			DEFAULT NULL COMMENT '涨跌幅',
	`OPEN_F_NET_PRICE`            				DECIMAL(30,10)  	  		DEFAULT NULL COMMENT '开盘远期净价',
	`LATEST_F_NET_PRICE`            			DECIMAL(30,10)  			DEFAULT NULL COMMENT '最新远期净价',
	`HIGHEST_F_NET_PRICE`            			DECIMAL(30,10)				DEFAULT NULL COMMENT '最高远期净价',
	`LOWEST_F_NET_PRICE`            			DECIMAL(30,10) 	  			DEFAULT NULL COMMENT '最低远期净价',
	`CLOSING_F_NET_PRICE`            			DECIMAL(30,10)  			DEFAULT NULL COMMENT '收盘远期净价',
	`WET_F_NET_PRICE`            				DECIMAL(30,10)  			DEFAULT NULL COMMENT '加权平均远期净价',
	`PRE_CLOSING_F_YIELD`             			DECIMAL(30,10)				DEFAULT NULL COMMENT '前收盘远期收益率',                                                                            
	`PRE_WET_F_YIELD`            				DECIMAL(30,10)				DEFAULT NULL COMMENT '前加权平均远期收益率',
	`OPEN_F_YIELD`            					DECIMAL(30,10)  	  		DEFAULT NULL COMMENT '开盘远期收益率',
	`LATEST_F_YIELD`            				DECIMAL(30,10)  		  	DEFAULT NULL COMMENT '最新远期收益率',
	`HIGHEST_F_YIELD`            				DECIMAL(30,10)  			DEFAULT NULL COMMENT '最高远期收益率',
	`LOWEST_F_YIELD`            				DECIMAL(30,10)				DEFAULT NULL COMMENT '最低远期收益率',                                                                           
	`CLOSING_F_YIELD`            				DECIMAL(30,10)				DEFAULT NULL COMMENT '收盘远期收益率',
	`WET_F_YIELD`            					DECIMAL(30,10)				DEFAULT NULL COMMENT '加权远期收益率',
	`TURN_OVER`             					VARCHAR(52)  				DEFAULT NULL COMMENT '成交量',
	`UNDERLYING_SECURITY_ID`            		VARCHAR(52)					DEFAULT NULL COMMENT '309标的',
	`UNDERLYING_SYMBOL`            				VARCHAR(30)					DEFAULT NULL COMMENT '311标的名称',                                                                            
	`UPDATE_TIME`             			VARCHAR(30)							DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券远期市场行情';
	
	
	
	
	--  创建表TTRD_CMDS_BOND_DEAL
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_BOND_DEAL` (
	`QID`                    					DECIMAL(16)   				DEFAULT NULL COMMENT '序列',
	`TRANSACT_TIME`  							VARCHAR(30)  				DEFAULT NULL COMMENT '行情日期',
	`BEG_DATE` 				 					CHAR(10)   	  				DEFAULT NULL COMMENT '开始日期',
	`PRE_MARKET_BOND_INDICATOR`         		CHAR(1)   	  				DEFAULT NULL COMMENT '上市前债券',
	`MDTYPE`            						CHAR(1)   	  				DEFAULT NULL COMMENT '市场行情-R',
	`MARKET_INDICATOR`            				CHAR(1)  		  			DEFAULT NULL COMMENT '市场行情子类型',
	`MDSUBTYPE`            						INT  	  					DEFAULT NULL COMMENT '市场标识',
	`TRADE_METHOD`            					INT 						DEFAULT NULL COMMENT '交易方式',
	`SECURITY_ID`            					VARCHAR(50)   				DEFAULT NULL COMMENT '交易品种代码',
	`SYMBOL`            						VARCHAR(50)   				DEFAULT NULL COMMENT '交易品种名称',
	`LATEST_TRANS_PRICE`            			DECIMAL(25,5) 	  			DEFAULT NULL COMMENT '最新成交净价',
	`SETTLE_TYPE1`            					CHAR(1)  	  				DEFAULT NULL COMMENT '清算速度1',
	`DIRECTION1`            					CHAR(1)  					DEFAULT NULL COMMENT '最新成交方向1',
	`LATEST_YTM`            					DECIMAL(25,5) 	  			DEFAULT NULL COMMENT '最新成交到期收益率',
	`SETTLE_TYPE2`            					CHAR(1)  					DEFAULT NULL COMMENT '清算速度2',
	`DIRECTION2`            					CHAR(1)  					DEFAULT NULL COMMENT '最新成交方向2',
	`HIGHEST_TRANS_PRICE`            			DECIMAL(25,5)				DEFAULT NULL COMMENT '最高成交净价',
	`HIGHEST_YTM`            					DECIMAL(25,5)  	  			DEFAULT NULL COMMENT '最高成交到期收益率',
	`LOWEST_TRANS_PRICE`            			DECIMAL(25,5)  		  		DEFAULT NULL COMMENT '最低成交净价',
	`LOWEST_YTM`            					DECIMAL(25,5)  				DEFAULT NULL COMMENT '最低成交到期收益率',
	`OPEN_PRICE`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '开盘价',                                                                           
	`OPEN_YTM`            						DECIMAL(25,5)				DEFAULT NULL COMMENT '开盘到期收益率',
	`PRE_OPEN_NET_PRICE`            			DECIMAL(25,5)				DEFAULT NULL COMMENT '前开盘净价',
	`PRE_OPEN_YTM`             					DECIMAL(25,5)  				DEFAULT NULL COMMENT '前开盘到期收益率',
	`WET_AVG_NET_PRICE`            				DECIMAL(25,5)				DEFAULT NULL COMMENT '加权平均净价',
	`WET_AVG_YTM`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '加权平均到期收益率', 
	`PRE_WET_AVG_NET_PRICE`            			DECIMAL(25,5)				DEFAULT NULL COMMENT '前加权平均净价',
	`PRE_WET_AVG_YTM`            				DECIMAL(25,5)				DEFAULT NULL COMMENT '前加权平均到期收益率',
	`PRE_CLOSE_NET_PRICE`             			DECIMAL(25,5)  				DEFAULT NULL COMMENT '前收盘净价',
	`PRE_CLOSE_YTM`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '前收盘到期收益率',
	`NET_VOL`            						DECIMAL(25,5)				DEFAULT NULL COMMENT '净价涨跌幅', 
	`YIEDL_VOL`            						DECIMAL(25,5)				DEFAULT NULL COMMENT '收益率涨跌',
	`TRADE_VOLUME`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '成交量',   	
	`UPDATE_TIME`             					VARCHAR(30)					DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券买卖成交行情（BOND)';
	
	
	
	--  创建表TTRD_CMDS_IR_SW_FIX_FLOAT_DEAL
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IR_SW_FIX_FLOAT_DEAL` (
	`QID`                    					DECIMAL(16)  				DEFAULT NULL COMMENT '序列',
	`TRANSACT_TIME`  							VARCHAR(30) 				DEFAULT NULL COMMENT '行情日期',
	`BEG_DATE` 				 					CHAR(10)   				DEFAULT NULL COMMENT '开始日期',
	`MDTYPE`         							CHAR(1)   					DEFAULT NULL COMMENT '市场行情-R',
	`MARKET_INDICATOR`            				CHAR(1)   					DEFAULT NULL COMMENT '市场行情子类型',
	`MDSUBTYPE`            						INT	  					DEFAULT NULL COMMENT '市场标识',
	`TRADE_LIMIT_DAYS`            				VARCHAR(15)					DEFAULT NULL COMMENT '期限',
	`BENCHMARK_CURVE_NAME`            			VARCHAR(50)					DEFAULT NULL COMMENT '参考利率',
	`SECURITY_ID`            					VARCHAR(50)  				DEFAULT NULL COMMENT '交易品种代码',
	`SYMBOL`            						VARCHAR(50)  				DEFAULT NULL COMMENT '交易品种名称',
	`PRE_CLS_FIX_RATE`            				DECIMAL(25,5) 	  			DEFAULT NULL COMMENT '前收盘固定利率',
	`PRE_WET_AVG_FIX_RATE`            			DECIMAL(25,5)  				DEFAULT NULL COMMENT '前加权平均固定利率',
	`OPEN_FIX_RATE`            					DECIMAL(25,5) 	  			DEFAULT NULL COMMENT '开盘固定利率',
	`LATEST_FIX_RATE`            				DECIMAL(25,5)				DEFAULT NULL COMMENT '最新固定利率',
	`HIGHEST_FIX_RATE`            				DECIMAL(25,5)				DEFAULT NULL COMMENT '最高固定利率',
	`LOWEST_FIX_RATE`            				DECIMAL(25,5)  	  			DEFAULT NULL COMMENT '最低固定利率',
	`CLOING_FIX_RATE`            				DECIMAL(25,5)  		  		DEFAULT NULL COMMENT '收盘固定利率',
	`WET_AVG_FIX_RATE`            				DECIMAL(25,5)  				DEFAULT NULL COMMENT '加权平均固定利率',
	`TURN_OVER`            						DECIMAL(25,5)  				DEFAULT NULL COMMENT '成交量',
	`UPDATE_TIME`             					VARCHAR(30)					DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券买卖成交行情（BOND)';
	
	
	--  创建表TTRD_CMDS_QUOTE_BOND_INDICATE
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_QUOTE_BOND_INDICATE` (
	`QID`                    					DECIMAL(16) 					DEFAULT NULL COMMENT '序列',
	`QUOTE_TRANS_TYPE`  						CHAR(1)						DEFAULT NULL COMMENT '报文会话类型',
	`TRANSACT_TIME` 				 			VARCHAR(30)					DEFAULT NULL COMMENT '业务发生时间',
	`QUOTE_ID`         							VARCHAR(30)					DEFAULT NULL COMMENT '报价编号',
	`SECURITY_ID`            					VARCHAR(50)					DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`            						VARCHAR(50)					DEFAULT NULL COMMENT '债券名称',
	`QUOTE_TYPE`            					INT							DEFAULT NULL COMMENT '报价类型-指示性报价',
	`MARKET_INDICATOR`            				CHAR(1)						DEFAULT NULL COMMENT '市场标示',
	`QUOTE_DATE`            					CHAR(10) 					DEFAULT NULL COMMENT '报价日期',
	`QUOTE_TIME`            					VARCHAR(30)					DEFAULT NULL COMMENT '报价时间',
	`QUOTE_STATUS`            					INT	  						DEFAULT NULL COMMENT '报价状态',
	`SIDE`            							CHAR(1) 					DEFAULT NULL COMMENT '交易方向',
	                                                                                              
	`B_ORDER_QTY`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '券面总额-买',
	`B_PRINCIPAL`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '每百元本金额-买（仅ABS传）',
	`B_TOTAL_PRINCIPAL`            				DECIMAL(25,5) 	  			DEFAULT NULL COMMENT '当前本金额-买（仅ABS传）',
	`B_SETTLE_TYPE`            					DECIMAL(25,5) 		  		DEFAULT NULL COMMENT '清算速度-买',
	`B_PRICE`            						DECIMAL(25,5) 				DEFAULT NULL COMMENT '净价-买',
	`B_YTM`                    					DECIMAL(25,5)				DEFAULT NULL COMMENT '到期收益率-买',
	                                                                                              
	`S_ORDER_QTY` 				 				DECIMAL(25,5)				DEFAULT NULL COMMENT '券面总额-卖',
	`S_PRINCIPAL`         						DECIMAL(25,5)				DEFAULT NULL COMMENT '每百元本金额-卖（仅ABS传）',
	`S_TOTAL_PRINCIPAL`            				DECIMAL(25,5)				DEFAULT NULL COMMENT '当前本金额-卖（仅ABS传）',
	`S_SETTLE_TYPE`            					DECIMAL(25,5)				DEFAULT NULL COMMENT '清算速度-卖',
	`S_PRICE`            						DECIMAL(25,5)				DEFAULT NULL COMMENT '净价-卖',
	`S_YTM`            							DECIMAL(25,5)				DEFAULT NULL COMMENT '到期收益率-卖',
	                                                                                              
	`PARTY_ID`            						VARCHAR(50)					DEFAULT NULL COMMENT '机构代码',
	`PARTY_ROLE`            					INT 	  					DEFAULT NULL COMMENT '报价方',
	`TRADER_NAME`            					VARCHAR(50) 				DEFAULT NULL COMMENT '交易员名称',
	`INSTITUTION_CHN_NAME`            			VARCHAR(50)	  				DEFAULT NULL COMMENT '机构中文简称',
	`ROUTING_TYPE`            					INT						DEFAULT NULL COMMENT '发送范围',
	`UPDATE_TIME`            					VARCHAR(30) 				DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='现券买卖指示性报价';
	
	
	
	
	--  创建表TTRD_CMDS_SBL_SERIES
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_SBL_SERIES` (
	`TRANSACTTIME`                    			VARCHAR(30)					DEFAULT NULL COMMENT '业务发生时间',
	`MDTYPE`  									VARCHAR(30)					DEFAULT NULL COMMENT '行情类型：本币市场行情',
	`MARKETINDICATOR` 				 			VARCHAR(20)					DEFAULT NULL COMMENT '市场类型：债券借贷',
	`MDSUBTYPE`         						INT							DEFAULT NULL COMMENT '市场行情类型：标的债券借贷费率行情，交易品种费率行情',
	`SECURITYID`            					VARCHAR(100)				DEFAULT NULL COMMENT '交易品种代码',
	`SYMBOL`            						VARCHAR(100)				DEFAULT NULL COMMENT '交易品种名称',
	`U_SECURITYID`            					VARCHAR(100)				DEFAULT NULL COMMENT '标的债券代码',
	`U_SYMBOL`            						VARCHAR(100)				DEFAULT NULL COMMENT '标的债券名称  ',
	`PRE_CLOSING_RATE`            				DECIMAL(25,8)				DEFAULT NULL COMMENT '前收盘费率（%）',
	`PRE_WEIGHTED_AVG_RATE`            			DECIMAL(25,8)				DEFAULT NULL COMMENT '前加权平均费率（%）',
	`OPENING_RATE`            					DECIMAL(25,8)				DEFAULT NULL COMMENT '开盘费率（%）',
	`LATEST_RATE`            					DECIMAL(25,8)				DEFAULT NULL COMMENT '最新费率（%）',	                                                                                              
	`HIGHEST_RATE`            					DECIMAL(25,8)				DEFAULT NULL COMMENT '最高费率（%）',
	`LOWEST_RATE`            					DECIMAL(25,8)				DEFAULT NULL COMMENT '最低费率（%）',
	`CLOSING_RATE`            					DECIMAL(25,8)	  			DEFAULT NULL COMMENT '收盘费率（%）',
	`WEIGHTED_AVG_RATE`            				DECIMAL(25,8) 		  		DEFAULT NULL COMMENT '加权平均费率（%）',
	`TURNOVER`            						DECIMAL(25,6)				DEFAULT NULL COMMENT '成交量（百万元）',
	`BEG_DATE`                    				CHAR(10)					DEFAULT NULL COMMENT '当前日期',                                                                                              
	`UPDATETIME`            					VARCHAR(30) 				DEFAULT NULL COMMENT '更新时间'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='债券借贷行情';
	
	-- 创建 S_AUTOINC_CMDS_EPID序列
	-- SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CMDS_EPID';
	-- IF ROWCOUNT = 0 THEN    -- 如果没有记录
	--	SELECT CURRENT_VAL INTO SEQNUM  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_EPID';
	--	SET SEQNUM = SEQNUM + 10000;
    --    INSERT INTO SEQUENCE VALUES('S_AUTOINC_CMDS_EPID',SEQNUM,1,1,2147483647);
    -- END IF;
	
	-- TIR_SERIES_AVERAGESHIBOR修改字段SHIBOR_AVE_TYPE
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'TIR_SERIES_AVERAGESHIBOR' AND COLUMN_NAME = 'SHIBOR_AVE_TYPE';
			SELECT DATA_TYPE INTO DATATYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='XIR' AND TABLE_NAME = 'TIR_SERIES_AVERAGESHIBOR' AND COLUMN_NAME = 'SHIBOR_AVE_TYPE';

		
	IF ROWCOUNT > 0 AND DATATYPE!='VARCHAR' THEN    -- 如果没有记录
		UPDATE TIR_SERIES_AVERAGESHIBOR SET SHIBOR_AVE_TYPE = NULL;
        ALTER TABLE TIR_SERIES_AVERAGESHIBOR MODIFY COLUMN SHIBOR_AVE_TYPE VARCHAR(10);
    END IF;
	
	
	SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'TTRD_CMDS_EXECUTIONREPORT' AND COLUMN_NAME = 'TRDTYPE';
	IF ROWCOUNT > 0 THEN
		ALTER TABLE `TTRD_CMDS_EXECUTIONREPORT` MODIFY COLUMN `TRDTYPE` VARCHAR(10) COMMENT "成交类别"; 
    END IF;
	
	
	
	CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SRS_BESTPRC_CUR` (
	`TRANSACTTIME`				  CHAR(30)      DEFAULT NULL COMMENT '行情时间',
	`BEG_DATE`                	  CHAR(30)      DEFAULT NULL COMMENT '行情更新时间',
	`MDTYPE`                      CHAR(30) 	 DEFAULT NULL COMMENT '人民币市场行情',
    `MDSUBTYPE`                   INT 			 DEFAULT NULL COMMENT '报价行情',
    `MARKETINDICATOR`             CHAR(30) 	 DEFAULT NULL COMMENT '质押式回购',
    `TRADEMETHOD`                 INT      	 DEFAULT NULL COMMENT '匿名点击',
	`ASK_PX`                      CHAR(30)      DEFAULT NULL COMMENT '报卖价',
    `SECURITYID`                  CHAR(100) 	 DEFAULT NULL COMMENT '合约名称',
    `SYMBOL`                      CHAR(50)      DEFAULT NULL COMMENT '合约品种',
    `ASK_TRADEVOLUME`             CHAR(30)      DEFAULT NULL COMMENT '报卖量',
    `ASK_ORDTYPE`                 CHAR(30)      DEFAULT NULL COMMENT '报卖订单类型',
    `ASK_NUMBEROFORDERS`          CHAR(30)      DEFAULT NULL COMMENT '报卖订单笔数',
    `BID_PX`                      CHAR(30)      DEFAULT NULL COMMENT '报买价',
    `BID_TRADEVOLUME`             CHAR(30)      DEFAULT NULL COMMENT '报买量',
    `BID_ORDTYPE`                 CHAR(30)      DEFAULT NULL COMMENT '报买订单类型',
    `BID_NUMBEROFORDERS`          CHAR(30)      DEFAULT NULL COMMENT '报卖订单笔数',
    `UPDATETIME`                  CHAR(30)       DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='最优报价行情-X-REPO';
	 

	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_CUR` (
	`MDTYPE`                  CHAR(30)       		DEFAULT NULL COMMENT '人民币市场行情',
	`MDSUBTYPE`               INT       	 		DEFAULT NULL COMMENT '市场行情类型：7-交易品种行情，37-存款类机构行情，8-回购利率市场行情，0-成交行情',
	`MARKETINDICATOR`         CHAR(50)       		DEFAULT NULL COMMENT '市场标识',
	`BEG_DATE`                CHAR(10)  	 		DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`            CHAR(21)       		DEFAULT NULL COMMENT '业务发生时间',
	`TRADEMETHOD`             INT       	 		DEFAULT NULL COMMENT '交易模式',
	`SECURITYID`              CHAR(100)      		DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`                  CHAR(100)      		DEFAULT NULL COMMENT '交易品种',
	`PRE_CLOSING_CLEANPRICE`  DECIMAL(25,8)       	DEFAULT NULL COMMENT '前收盘利率',
	`PRE_WEIGHTED_CLEANPRICE` DECIMAL(25,8)        	DEFAULT NULL COMMENT '前加权平均利率',
	`OPENING_CLEANPRICE`      DECIMAL(25,8)       	DEFAULT NULL COMMENT '开盘利率',
	`LATEST_CLEANPRICE`       DECIMAL(25,8)       	DEFAULT NULL COMMENT '最新利率',
	`HIGHEST_CLEANPRICE`      DECIMAL(25,8)       	DEFAULT NULL COMMENT '最高利率',
	`LOWEST_CLEANPRICE`       DECIMAL(25,8)       	DEFAULT NULL COMMENT '最低利率',
	`CLOSING_CLEANPRICE`      DECIMAL(25,8)       	DEFAULT NULL COMMENT '收盘利率',
	`WEIGHTED_CLEANPRICE`     DECIMAL(25,8)       	DEFAULT NULL COMMENT '加权平均利率',
	`WEIGHTED_YIELD_IR`       DECIMAL(38,6)       	DEFAULT NULL COMMENT '加权平均利率（利率债）',
	`TURNOVER`                DECIMAL(38,6)       	DEFAULT NULL COMMENT '成交量',
	`AVGTERM`                 CHAR(50)       		DEFAULT NULL COMMENT '平均期限',
	`TRANSACTIONNUM`          INT       			DEFAULT NULL COMMENT '成交笔数',
	`UPDATETIME`              CHAR(30)  			DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='质押式回购行情当前表';


CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_DEPTH_CUR` (
	`TRANSACTTIME`     CHAR(30)    	DEFAULT NULL COMMENT '行情更新时间',
	`MARKETINDICATOR`  CHAR(30)    	DEFAULT NULL COMMENT '质押式回购',
	`TRADEMETHOD`      DECIMAL(10)   DEFAULT NULL COMMENT '匿名点击',
	`SECURITYID`       CHAR(100) 	DEFAULT NULL COMMENT '合约名称',
	`MDTYPE`           CHAR(30)      DEFAULT NULL COMMENT '人民币市场行情',
	`MDSUBTYPE`        DECIMAL(10)   DEFAULT NULL COMMENT '报价行情',
	`MDBOOKTYPE`       DECIMAL(10)   DEFAULT NULL COMMENT '价格深度',
	`MARKETDEPTH`      DECIMAL(10)   DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
	`ASK_PX1`          CHAR(30)    	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME1` CHAR(30)    	DEFAULT NULL COMMENT '报卖量',
	`ASK_ORDTYPE1`     CHAR(30)    	DEFAULT NULL COMMENT '报卖订单类型',
	`ASK_PX2`          CHAR(30)    	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME2` CHAR(30)    	DEFAULT NULL COMMENT '报卖量',
	`ASK_ORDTYPE2`     CHAR(30)    	DEFAULT NULL COMMENT '报卖订单类型',
	`ASK_PX3`          CHAR(30)    	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME3` CHAR(30)    	DEFAULT NULL COMMENT '报卖量',
	`ASK_ORDTYPE3`     CHAR(30)    	DEFAULT NULL COMMENT '报卖订单类型',
	`ASK_PX4`          CHAR(30)    	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME4` CHAR(30)    	DEFAULT NULL COMMENT '报卖量',
	`ASK_ORDTYPE4`     CHAR(30)    	DEFAULT NULL COMMENT '报卖订单类型',
	`ASK_PX5`          CHAR(30)    	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME5` CHAR(30)    	DEFAULT NULL COMMENT '报卖量',
	`ASK_ORDTYPE5`     CHAR(30)    	DEFAULT NULL COMMENT '报卖订单类型',
	`BID_PX1`          CHAR(30)    	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME1` CHAR(30)    	DEFAULT NULL COMMENT '报买量',
	`BID_ORDTYPE1`     CHAR(30)    	DEFAULT NULL COMMENT '报买订单类型',
	`BID_PX2`          CHAR(30)    	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME2` CHAR(30)    	DEFAULT NULL COMMENT '报买量',
	`BID_ORDTYPE2`     CHAR(30)    	DEFAULT NULL COMMENT '报买订单类型',
	`BID_PX3`          CHAR(30)    	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME3` CHAR(30)    	DEFAULT NULL COMMENT '报买量',
	`BID_ORDTYPE3`     CHAR(30)    	DEFAULT NULL COMMENT '报买订单类型',
	`BID_PX4`          CHAR(30)    	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME4` CHAR(30)    	DEFAULT NULL COMMENT '报买量',
	`BID_ORDTYPE4`     CHAR(30)    	DEFAULT NULL COMMENT '报买订单类型',
	`BID_PX5`          CHAR(30)    	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME5` CHAR(30)    	DEFAULT NULL COMMENT '报买量',
	`BID_ORDTYPE5`     CHAR(30)    	DEFAULT NULL COMMENT '报买订单类型',
	`UPDATETIME`       CHAR(30)    	DEFAULT NULL COMMENT '更新时间',
	`SYMBOL`           CHAR(50)		DEFAULT NULL COMMENT '交易品种'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='报价深度行情';
	 
	 
	 
	 
	 CREATE TABLE IF NOT EXISTS `TTRD_CMDS_CR_SERIES_INST_CUR` (
	`MDTYPE`              CHAR(30)   	DEFAULT NULL COMMENT '市场类型',
	`MDSUBTYPE`           INT   		DEFAULT NULL COMMENT '市场行情类型',
	`MARKETINDICATOR`     CHAR(50)   	DEFAULT NULL COMMENT '市场标识',
	`BEG_DATE`            CHAR(10)  	DEFAULT NULL COMMENT '开始时间',
	`TRANSACTTIME`        CHAR(21)      DEFAULT NULL COMMENT '行情更新时间',
	`SECURITYID`          CHAR(100)   	DEFAULT NULL COMMENT '债券代码',
	`SYMBOL`              CHAR(100)   	DEFAULT NULL COMMENT '债券名称',
	`WEIGHTED_CLEANPRICE` DECIMAL(25,8) DEFAULT NULL COMMENT '加权平均利率',
	`PARTYID`             CHAR(150)     DEFAULT NULL COMMENT '机构展示类型',
	`DIRECTION`           CHAR(1)       DEFAULT NULL COMMENT '交易方向',
	`UPDATETIME`          CHAR(30)		DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='质押式回购分机构类型盘中行情';


CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSP_BESTQTE_CUR` (
	`TRANSACTTIME`    CHAR(30)   DEFAULT NULL COMMENT '行情更新时间',
	`MDTYPE`          CHAR(30)   DEFAULT NULL COMMENT '人民币市场行情',
	`MDSUBTYPE`       DECIMAL(10)     DEFAULT NULL COMMENT '报价行情',
	`MARKETINDICATOR` CHAR(30)   DEFAULT NULL COMMENT '利率互换',
	`TRADEMETHOD`     DECIMAL(10)     DEFAULT NULL COMMENT '匿名点击',
	`SECURITYID`      CHAR(100)  DEFAULT NULL COMMENT '债券代码',
	`BID_PX`          CHAR(30)   DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME` CHAR(30)   DEFAULT NULL COMMENT '报买量',
	`ASK_PX`          CHAR(30)   DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME` CHAR(30)   DEFAULT NULL COMMENT '报卖量',
	`UPDATETIME`      CHAR(30) 	 DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='最优报价行情';

CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSP_DEPTHQTE_CUR` (
	`TRANSACTTIME`     CHAR(30)  	DEFAULT NULL COMMENT '报价深度行情的更新时间',
	`MDTYPE`           CHAR(30) 	DEFAULT NULL COMMENT '人民币市场行情',
	`MDSUBTYPE`        DECIMAL(10) DEFAULT NULL COMMENT '报价行情',
	`MARKETINDICATOR`  CHAR(30) 	DEFAULT NULL COMMENT '利率互换',
	`TRADEMETHOD`      DECIMAL(10) DEFAULT NULL COMMENT '匿名点击',
	`SECURITYID`       CHAR(100)  	DEFAULT NULL COMMENT '债券代码',
	`MDBOOKTYPE`       DECIMAL(10) DEFAULT NULL COMMENT '价格深度',
	`MARKETDEPTH`      DECIMAL(10) DEFAULT NULL COMMENT '5-5档行情；3-3档行情；1-1档行情',
	`BID_PX1`          CHAR(30) 	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME1` CHAR(30) 	DEFAULT NULL COMMENT '报买量',
	`BID_PX2`          CHAR(30) 	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME2` CHAR(30) 	DEFAULT NULL COMMENT '报买量',
	`BID_PX3`          CHAR(30) 	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME3` CHAR(30) 	DEFAULT NULL COMMENT '报买量',
	`BID_PX4`          CHAR(30) 	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME4` CHAR(30) 	DEFAULT NULL COMMENT '报买量',
	`BID_PX5`          CHAR(30) 	DEFAULT NULL COMMENT '报买价',
	`BID_TRADEVOLUME5` CHAR(30) 	DEFAULT NULL COMMENT '报买量',
	`ASK_PX1`          CHAR(30) 	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME1` CHAR(30) 	DEFAULT NULL COMMENT '报卖量',
	`ASK_PX2`          CHAR(30) 	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME2` CHAR(30) 	DEFAULT NULL COMMENT '报卖量',
	`ASK_PX3`          CHAR(30) 	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME3` CHAR(30) 	DEFAULT NULL COMMENT '报卖量',
	`ASK_PX4`          CHAR(30) 	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME4` CHAR(30) 	DEFAULT NULL COMMENT '报卖量',
	`ASK_PX5`          CHAR(30) 	DEFAULT NULL COMMENT '报卖价',
	`ASK_TRADEVOLUME5` CHAR(30) 	DEFAULT NULL COMMENT '报卖量',
	`UPDATETIME`       CHAR(30) 	DEFAULT NULL COMMENT '市场类型'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='深度行情';


CREATE TABLE IF NOT EXISTS `TTRD_CMDS_IRS_XSP_TRADEQTE_CUR` (
	`TRANSACTTIME`           CHAR(30)   		DEFAULT NULL COMMENT '行情更新时间',
	`MDTYPE`                 CHAR(30)   		DEFAULT NULL COMMENT '人民币市场行情',
	`MDSUBTYPE`              DECIMAL(10)     	DEFAULT NULL COMMENT '成交行情',
	`MARKETINDICATOR`        CHAR(30)   		DEFAULT NULL COMMENT '利率互换',
	`TRADEMETHOD`            DECIMAL(10)     	DEFAULT NULL COMMENT '匿名点击',
	`SECURITYID`             CHAR(100)  		DEFAULT NULL COMMENT '债券代码',
	`LASTRATE`               CHAR(30)   		DEFAULT NULL COMMENT '最新利率',
	`TRADEVOLUME`            CHAR(30)   		DEFAULT NULL COMMENT '最新成交量',
	`OPENRATE`               CHAR(30)   		DEFAULT NULL COMMENT '开盘利率',
	`HIGHESTRATE`            CHAR(30)   		DEFAULT NULL COMMENT '最高利率',
	`LOWESTRATE`             CHAR(30)   		DEFAULT NULL COMMENT '最低利率',
	`INTRADAYREFERENCEPRICE` CHAR(30)   		DEFAULT NULL COMMENT '盘中参考价',
	`CUMULATIVEVOLUME`       CHAR(30)   		DEFAULT NULL COMMENT '当日累计成交量',
	`UPDATETIME`             CHAR(30)			DEFAULT NULL COMMENT '更新时间'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='成交行情';


CREATE TABLE IF NOT EXISTS `TTRD_CFETS_IMIX_STATUS` (
	`QID`           				CHAR(30)  		DEFAULT NULL COMMENT '序列号',
	`SERVERNAME`                 	CHAR(100)  		DEFAULT NULL COMMENT '服务名称',
	`SERVERSTATUS`              	CHAR(30)  	DEFAULT NULL COMMENT '服务状态',
	`ERRDESC`        				CHAR(50)   		DEFAULT NULL COMMENT '错误描述',
	`UPDATETIME`            		CHAR(30)  	DEFAULT NULL COMMENT '行情更新时间',
	`SERVERTYPE`             		CHAR(50) 		DEFAULT NULL COMMENT '服务类型'
) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='会话状态表';


-- 创建 S_AUTOINC_CFETS_TRADE_QID序列
	-- SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CFETS_TRADE_QID';
	-- IF ROWCOUNT = 0 THEN    -- 如果没有记录
    --   INSERT INTO SEQUENCE VALUES('S_AUTOINC_CFETS_TRADE_QID',1,1,1,2147483647);
    -- END IF;	
	
	-- 收盘估值脚本合并 
	CREATE TABLE IF NOT EXISTS `TTRD_CMDS_LOCK_TABLE` (
	`ID`           				INT  		DEFAULT NULL COMMENT '序列号'
	) ENGINE=INNODB DEFAULT CHARSET=UTF8;
	
	SELECT COUNT(*) INTO ROWCOUNT  FROM TTRD_CMDS_LOCK_TABLE;
	IF ROWCOUNT = 0 THEN    -- 如果没有记录
        INSERT INTO TTRD_CMDS_LOCK_TABLE VALUES(1);
    END IF;
	
	-- SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CAID';
	-- IF ROWCOUNT = 0 THEN    -- 如果没有记录
    --    INSERT INTO SEQUENCE VALUES('S_AUTOINC_CAID',1,1,1,2147483647);
    -- END IF;
	
	-- TIR_SERIES_BOND_CL_ASSESS增加字段CAID
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TIR_SERIES_BOND_CL_ASSESS'
    AND COLUMN_NAME = 'CAID';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TIR_SERIES_BOND_CL_ASSESS ADD CAID INT  DEFAULT NULL COMMENT '序号';
    END IF;
	
	
	-- TIR_SERIES_BOND_CL_ASSESS增加字段STATUS
    SELECT COUNT(COLUMN_NAME) INTO ROWCOUNT
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = 'TIR_SERIES_BOND_CL_ASSESS'
    AND COLUMN_NAME = 'STATUS';
 
    IF ROWCOUNT = 0 THEN    -- 如果没有记录
        ALTER TABLE TIR_SERIES_BOND_CL_ASSESS ADD STATUS CHAR(1)  DEFAULT NULL COMMENT '数据向MD库的迁移状态，0-未迁移，1-迁移成功，2-迁移失败';
    END IF;

	-- 创建序列表
    CREATE TABLE IF NOT EXISTS `SEQUENCE` (
   `SEQ_NAME` VARCHAR(50) NOT NULL,
   `CURRENT_VAL` INT(11) NOT NULL,
   `INCREMENT_VAL` INT(11) NOT NULL DEFAULT '1',
   `MIN_VAL` INT(11) NOT NULL DEFAULT '1',
   `MAX_VAL` BIGINT(20) NOT NULL DEFAULT '2147483647',
   `CACHE_SIZE` INT(11) DEFAULT '100' COMMENT '缓存步长',
    PRIMARY KEY (`SEQ_NAME`)
    ) ENGINE=INNODB DEFAULT CHARSET=UTF8;
	
	-- 创建 S_AUTOINC_EPID 序列
	SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_EPID';
	IF ROWCOUNT = 0 THEN    -- 如果没有记录
        INSERT INTO SEQUENCE VALUES('S_AUTOINC_EPID',0,1,1,2147483647,100);
    END IF;
	
	-- 创建 S_AUTOINC_CMDS_EPID 序列
	SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CMDS_EPID';
	IF ROWCOUNT = 0 THEN    -- 如果没有记录
        INSERT INTO SEQUENCE VALUES('S_AUTOINC_CMDS_EPID',0,1,1,2147483647,100);
    END IF;
	
	-- 创建 S_AUTOINC_CFETS_TRADE_QID 序列
	SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CFETS_TRADE_QID';
	IF ROWCOUNT = 0 THEN    -- 如果没有记录
        INSERT INTO SEQUENCE VALUES('S_AUTOINC_CFETS_TRADE_QID',0,1,1,2147483647,100);
    END IF;
	
	-- 创建 S_AUTOINC_CAID 序列
	SELECT COUNT(*) INTO ROWCOUNT  FROM SEQUENCE WHERE SEQ_NAME = 'S_AUTOINC_CAID';
	IF ROWCOUNT = 0 THEN    -- 如果没有记录
        INSERT INTO SEQUENCE VALUES('S_AUTOINC_CAID',0,1,1,2147483647,100);
    END IF;
END;

