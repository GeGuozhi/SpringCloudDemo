create view v_tp_stg_option_leg_sign as
select '' AS `TSK_ID`, '' AS `I_CODE`, '' AS `A_TYPE`, '' AS `M_TYPE`, 1 AS `LEGSIGN`
from DUAL
where (1 = 0);

