create view vcfetstrade_all_req_table as
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_dlg_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_pl_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_mm_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_dlg_reply` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_cd_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_query` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_rfq_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_rfq_res_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_rfq_rej` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_ind_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_md_subscribe` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_rfq_res_cfm` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_quick_cancel` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_anon_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_fak_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_crdlg_send` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       ''                      AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_crdlg_reply` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_risklimit_qry` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       ''                      AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_risklimit_set` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_xswap_reply` `T`
union
select `T`.`QID`               AS `QID`,
       `T`.`ACTION`            AS `ACTION`,
       `T`.`MARKETINDICATOR`   AS `MARKETINDICATOR`,
       `T`.`CLIENT_ID`         AS `CLIENT_ID`,
       `T`.`CLORDID`           AS `CLORDID`,
       `T`.`CLORDID_CLIENT_ID` AS `CLORDID_CLIENT_ID`,
       `T`.`STATUS`            AS `STATUS`,
       `T`.`ERRORCODE`         AS `ERRORCODE`,
       `T`.`ERRORMSG`          AS `ERRORMSG`
from `xir`.`ttrd_cfets_trade_xswap_send` `T`;

