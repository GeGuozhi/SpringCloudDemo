create
    definer = root@`%` procedure PROC_CFETS_XSWAP_REQ_ORDER(IN PI_USERNAME varchar(30), IN PI_CLIENTID varchar(30),
                                                            IN PI_CLIENTREQID varchar(30), IN PI_ORDDATE varchar(30),
                                                            IN PI_ORDTIME varchar(30), IN PI_FAR_NEAR_FLAG varchar(30),
                                                            IN PI_APPLTOKEN varchar(30), IN PI_SIDE varchar(30),
                                                            IN PI_ORDTYPE varchar(30), IN PI_EXPIRETIME varchar(30),
                                                            IN PI_PRICE varchar(30), IN PI_ORDERQTY varchar(30),
                                                            IN PI_SECURITYID varchar(30),
                                                            IN PI_MARKETINDICATOR varchar(30),
                                                            IN PI_SECURITYTYPE varchar(30),
                                                            IN PI_CLEARINGMETHOD varchar(30), IN PI_PARTY varchar(30),
                                                            IN PI_TRADER varchar(30), IN PI_STATUS decimal(18),
                                                            IN PI_FB_OPERATESEQNUM varchar(30),
                                                            IN PI_FB_ORDERID varchar(30),
                                                            IN PI_FB_TRANSACTTIME varchar(30),
                                                            IN PI_UPDATETIME varchar(30), IN PI_SERIALNO varchar(30),
                                                            IN PI_LEAVESQTY varchar(30), IN PI_QUOTESOURCE varchar(30),
                                                            IN PI_CREATETIME varchar(30), OUT PO_SYSREQID varchar(30),
                                                            OUT PO_ORDERREQUESTID varchar(30),
                                                            OUT PO_ERRCODE varchar(30), OUT PO_ERRINFO varchar(1000))
label_a:BEGIN
  DECLARE V_COUNT DECIMAL(18,0);
  DECLARE V_DATE VARCHAR(30);
  SET V_DATE = '';
  SET PO_ERRCODE = '0';
  SET PO_ERRINFO  = '';

  SELECT curdate() INTO V_DATE FROM DUAL;
  SET V_DATE = CONCAT(V_DATE, ' 00:00:00.000');
  
  SELECT COUNT(1)
    INTO V_COUNT
    FROM TTRD_XSWAP_ORDER
   WHERE CLIENTID = PI_CLIENTID
     AND CLIENTREQID = PI_CLIENTREQID
     AND ORDDATE = PI_ORDDATE
     AND (STATUS = 0 OR STATUS = 1 OR STATUS = 2 OR STATUS = 3 OR STATUS = 5 OR STATUS = 6)
	 AND UPDATETIME > V_DATE;
  IF V_COUNT > 0 THEN
    SET PO_ERRCODE := '-30006';
    SET PO_ERRINFO := '禁止重复报价';
    LEAVE label_a;
  END IF;

  SELECT NEXTVAL('S_AUTOINC_XSWAP_SYSREQID') INTO PO_SYSREQID FROM DUAL;
  
  SET PO_ORDERREQUESTID = PO_SYSREQID;
  IF CHAR_LENGTH(PO_ORDERREQUESTID) > 8 THEN
    SET PO_ORDERREQUESTID = LEFT(PO_ORDERREQUESTID, 8);
  ELSEIF CHAR_LENGTH(PO_ORDERREQUESTID) < 8 THEN
    WHILE CHAR_LENGTH(PO_ORDERREQUESTID) < 8 DO
		SET PO_ORDERREQUESTID = CONCAT('0',PO_ORDERREQUESTID);
    END WHILE;
  END IF;
  SET PO_ORDERREQUESTID = CONCAT('ORDE',REPLACE(PI_ORDDATE, '-', ''),PI_USERNAME,PO_ORDERREQUESTID);
  
  IF CHAR_LENGTH(PI_CLEARINGMETHOD) <= 0 THEN
	SET PI_CLEARINGMETHOD = null;
  END IF;

  INSERT INTO TTRD_XSWAP_ORDER
    (SYSREQID,
     CLIENTID,
     CLIENTREQID,
     ORDDATE,
     ORDTIME,
     FAR_NEAR_FLAG,
     ORDERREQUESTID,
     APPLTOKEN,
     SIDE,
     ORDTYPE,
     EXPIRETIME,
     PRICE,
     ORDERQTY,
     SECURITYID,
     MARKETINDICATOR,
     SECURITYTYPE,
     CLEARINGMETHOD,
     PARTY,
     TRADER,
     STATUS,
     ERRCODE,
     ERRINFO,
     FB_OPERATESEQNUM,
     FB_ORDERID,
     FB_TRANSACTTIME,
     UPDATETIME,
     SERIALNO,
     LEAVESQTY,
	 QUOTESOURCE,
	 CREATETIME)
  VALUES
    (PO_SYSREQID,
     PI_CLIENTID,
     PI_CLIENTREQID,
     PI_ORDDATE,
     PI_ORDTIME,
     PI_FAR_NEAR_FLAG,
     PO_ORDERREQUESTID,
     PI_APPLTOKEN,
     PI_SIDE,
     PI_ORDTYPE,
     PI_EXPIRETIME,
     PI_PRICE,
     PI_ORDERQTY,
     PI_SECURITYID,
     PI_MARKETINDICATOR,
     PI_SECURITYTYPE,
     PI_CLEARINGMETHOD,
     PI_PARTY,
     PI_TRADER,
     PI_STATUS,
     PO_ERRCODE,
     PO_ERRINFO,
     PI_FB_OPERATESEQNUM,
     PI_FB_ORDERID,
     PI_FB_TRANSACTTIME,
     PI_UPDATETIME,
     PI_SERIALNO,
     PI_LEAVESQTY,
	 PI_QUOTESOURCE,
	 PI_CREATETIME);

END;

